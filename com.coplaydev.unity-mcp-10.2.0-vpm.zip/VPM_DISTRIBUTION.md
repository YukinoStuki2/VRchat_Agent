# Coplay 10.2.0 — unofficial VPM redistribution

Original: https://github.com/CoplayDev/unity-mcp/tree/30d22075093d1d35dfb0091c1c7550e9ad948577/MCPForUnity

Copyright (c) 2025 CoplayDev. MIT license included as LICENSE.
Distributed by Yukino for com.yukino.vrchat-agent dependency resolution.
Not an official Coplay VPM release or endorsement. All upstream source and .meta bytes are preserved; only package.json distribution fields and these notice/license files are added.
VPM installation does not modify Coplay Editor initialization or grant Yukino Agent task permissions.
