# 宿主接入说明（离线候选，未安装）

**两种互斥入口。** 缺省不注册普通聊天读取工具；`/vrc 开始/列表/绑定/问/停止/关闭` 仍走原独立会话。自然读取须在指定 profile 显式设置布尔 `receipt_reads: true`，且 `image_egress: false`。此模式保留开始/列表/停止/关闭管理命令，不提供广义模型、图片或手工取结果；不根据对端能力自动切换模式。

在经审核的 Linux profile 中，按原有方式启用 `vrchat-agent-candidate`，在**新会话**启用其同名工具集。不要改动正在运行的 agent。`settings` 示例（不是部署脚本）：

```yaml
receipt_reads: true
image_egress: false
socket: /absolute/private-0700-directory/receiver.sock
owners:
  - {platform: qqbot, user: OWNER_OPENID, chat: OWNER_OPENID, profile: null, thread: null}
include: [agent_prepare, manage_scene, agent_scene_receipt]
```

使用本地核实的精确主人身份；一个接收器只服务一个操作者。导入不监听；socket 目录须同 UID 独占、权限 0700。正常用法（已有普通主人私聊会话）：

1. 说「打开 Unity 接收入口」，在 Unity 手动交付工程。说「连接 Unity 工程」列出选择，再说「连接 Unity 工程 列表首列标识」或「绑定 Unity 连接 完整编号」。不自动认领。认领先用 `agent_status` 核对工程身份；它不是自然绑定开放的工具。
2. 在 Unity 权限页允许所需读取能力。问「巧克力，看看我现在打开的是哪个场景」或「列出 Hierarchy 第一层前五个物体」，也可合问。仅从当前原始文本确认范围，引用、历史和模型选择不能单独授权。未识别的问法仍交给普通聊天。
3. 在 Unity 任务页核对并批准本次清单。**不用再问、不用回码、不用发命令。** 宿主最多等 90 秒，仅轮询本清单的状态。批准后每个操作只尝试一次；结果只含活动场景名和/或当前 Stage 首屏最多五个根对象名。被动回复原主人私聊的原消息，不回注模型。失效、断线、结果未确认均不自动重试或续权。
4. `/vrc 停止` 撤销本聊天绑定；`/stop`、`/new`、`/reset` 仍留给宿主并撤销本绑定。`/vrc 关闭` 在无其他绑定路由时关闭接收器。清理失败须在 Unity 本地核实。不能撤回已发出的请求。

仅支持有原生回调、活动回合凭证、能验证入站与投递适配器的 QQ C2C。旧端缺少精确回执时需更新 Unity 对端后重新交付；不会用试读探测批准。执行时必须由 Unity 再核对当前身份、计划、批准和有效期。

## SSH部署前置条件（不是自动配置脚本）

远端管理员需提供固定 `vrchat-agent-handoff` SSH subsystem，执行固定绝对路径的 Hermes Python 与
本插件 `hermes_handoff_relay.py`，传入固定绝对 socket 路径。relay只收发管道协议，不接受远程脚本/任意路径。
管理员必须审查 SSH 服务端及每把操作者公钥的授权策略：仅可信操作者密钥；禁密码、交互shell/任意exec、PTY、agent/X11转发；
只允许所需的远端 **127.0.0.1** 监听端口，`GatewayPorts no`。既有 SSH 服务、用户和信任文件不由插件修改。
同 UID 连接验证不证明已经配置这些限制；真实跨机部署仍需单独验收。

本机预先核实主机指纹并配置 SSH agent/系统可信密钥；启动使用 BatchMode、StrictHostKeyChecking 和固定子系统。
不得在命令行、配置文件或日志中填写本轮短期凭据。凭据由 Unity owner 内存经私有管道和 SSH stdin 交付。
管理机回环转发端口不是公网监听，也不是工程原始HTTP authority；两者会分别固定核对。

