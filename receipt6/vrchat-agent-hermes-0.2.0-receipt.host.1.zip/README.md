# Unity 场景只读回执 · Hermes 宿主候选

默认保留独立 `/vrc` 专用会话。显式开启 `receipt_reads: true` 后，已绑定工程的主人可在普通 QQ 私聊提问，在 Unity 本地批准一次，结果被动回复原消息。两种模式不混用，不热改正在运行的 agent。

配置、能力范围和旧端限制见 [INSTALL.md](INSTALL.md)。本目录是完整插件，不是已发布或已部署的版本。
