"""Manual Hermes gateway plugin controller. Import/register starts nothing.

pre_gateway_dispatch precedes Hermes auth, so BOTH explicit owner-route matching
and the live gateway authorization check are mandatory. No MCP tools or slash
handlers can claim offers. /vrc uses a separate conversation; explicit QQ
read selections use a fixed read protocol without a model or published tools.
"""
import asyncio
from pathlib import Path
import re
if __package__:
    from . import hermes_natural as natural
    from .hermes_chat import ChatHost, finish
else:
    import hermes_natural as natural
    from hermes_chat import ChatHost, finish


class GatewayPlugin:
    def __init__(self, ctx):
        self.ctx = ctx
        self.host = None
        self.runner = None
        self.pending = set()
        self.controls = {}  # bounded separately, one completion per (configured route, control)
        self.generation = 0
        self.stop = None
        self.ready = None
        self.closing = False
        self.failed = False
        self.routes = set()
        self.stop_epoch = {}  # bounded by configured owner routes
        self.path = None
        self.include = ()
        owners = ctx.get_config('owners', [])
        include = ctx.get_config('include', [])
        path = ctx.get_config('socket', '')
        self.image_egress = ctx.get_config('image_egress',False)
        if type(self.image_egress) is not bool:
            raise ValueError('candidate_image_setting_invalid')
        if (type(owners) is list and 1 <= len(owners) <= 8 and type(include) is list
                and 1 <= len(include) <= 64 and all(type(n) is str and re.fullmatch('[A-Za-z0-9_-]{1,128}', n) for n in include)
                and len(set(include)) == len(include) and type(path) is str and Path(path).is_absolute()):
            for owner in owners:
                if (type(owner) is not dict or set(owner) != {'platform','user','chat','profile','thread'}
                        or any(type(owner[k]) is not str or not owner[k] for k in ('platform','user','chat'))
                        or any(owner[k] is not None and (type(owner[k]) is not str or not owner[k]) for k in ('profile','thread'))):
                    self.routes.clear()
                    break
                self.routes.add(tuple(owner[k] for k in ('platform','user','chat','profile','thread')))
            # One private receiver is one operator, not a cross-user offer queue.
            if len({(r[0], r[1], r[3]) for r in self.routes}) != 1:
                self.routes.clear()
            self.path = Path(path)
            self.include = tuple(include)
            if 'visual_collect' in include and not self.image_egress:self.routes.clear()
        from .hermes_read import ReadFacade
        mode = ctx.get_config('receipt_reads', False)
        if type(mode) is not bool or (mode and self.image_egress):
            raise ValueError('candidate_read_mode_invalid')
        self.read = ReadFacade(self, ctx) if mode else None
        ctx.register_hook('pre_gateway_dispatch', self.dispatch)
        ctx.on_unload(self.request_close)

    def dispatch(self, *, event, gateway, **unused):
        text = getattr(event, 'text', '')
        if type(text) is not str:
            return None
        command, _, args = text.strip().partition(' ')
        reset = command.lower() in ('/stop','/new','/reset')
        from .hermes_read import direct
        if self.read and not direct(event,gateway):return None
        nl = None
        observation = False
        if command.lower() != '/vrc' and not reset:
            if not self.read:return None
            nl = natural.intent(text)
            if nl is None:
                if event.is_command():return None
                observation=True
            else:args=nl
        elif self.read and not reset and args not in ('开始','列表','停止','关闭'):
            return {'action':'skip','reason':'read_only_plugin'}
        skipped = None if reset else {'action':'skip', 'reason':'candidate_private_command'}
        source = getattr(event, 'source', None)
        declined = None if nl or observation else skipped
        if self.closing or source is None:
            return declined
        try:
            identity = source.to_dict()
            # Hermes omits false-valued profile fields; do not turn an invalid
            # empty profile into the authorized default (None) route.
            if identity.get('profile') != getattr(source, 'profile'):
                return declined
            route = (identity['platform'], identity['user_id'], identity['chat_id'],
                     identity.get('profile'), identity['thread_id'])
        except Exception:
            return declined  # incomplete/failed source serialization grants nothing
        if (route not in self.routes or source.chat_type != 'dm' or source.is_bot
                or source.profile_route_rejected
                or getattr(event, 'user_id', None) not in (None, source.user_id)):
            return declined
        try:
            if nl and route[0] != 'qqbot':
                return None
            if route[0] == 'qqbot' and not natural.direct_qq_text(event, source):
                return None if nl else skipped
            if gateway._is_user_authorized_for_source(source) is not True:
                return declined
            if observation:
                chat=self.host.chats.get(route) if self.host else None
                if chat:
                    chat.ticket=None
                    if not natural.host_controls_input(gateway,source):self.read.observe(gateway,event,chat)
                return None
            if nl and natural.host_controls_input(gateway, source):
                return None
            asyncio.get_running_loop()  # reviewed hook runs on gateway caller thread
            if reset or args in ('停止','关闭'):
                self.stop_epoch[route] = self.stop_epoch.get(route, 0) + 1
            if self.host is not None and reset:
                self.host.request_stop(route)
            if reset:
                return None
            if args in ('关闭','停止'):
                self._control(route,args,source,event.message_id,gateway)
                return skipped
            # Do not admit a new generation while a revocation completion can
            # still coalesce another stop for this route.
            if any(r==route or action=='关闭' for r,action in self.controls):return skipped
            if len(self.pending) >= 8:
                return skipped
            pinned=self._selection_session(gateway,source) if nl and nl.startswith(('project ','offer ')) else None
            owner = (self.host, self.host.chats.get(route) if self.host else None, self.stop_epoch.get(route, 0)) if nl or pinned else None
            task = self.ctx.spawn_task(self._request(route, args, source, event.message_id, gateway, owner=owner, pinned=pinned,
                generation=(self.generation,self.stop_epoch.get(route,0))),
                                       name='candidate-command')
            self.pending.add(task)
            task.add_done_callback(self.pending.discard)
        except Exception:
            self.failed = True
        return None if observation else skipped

    @staticmethod
    def _selection_session(gw,src):
        from .hermes_read import session
        try:return session(gw,src)
        except (ValueError,AttributeError):return ()

    def _control(self, route, action, src, mid, gw):
        key = route,action
        if key in self.controls:return
        host, runner = self.host, self.runner
        chat = host.chats.get(route) if host else None
        # Decide and fence synchronously: no new bind can enter between the
        # other-route check and close. Cleanup does not depend on reply delivery.
        refused = action == '关闭' and host and any(r != route for r in host.chats)
        if not refused:
            if action == '关闭':
                self.generation += 1
                if host:host.closing = True
                if self.stop:self.stop.set()
            if chat:host.request_stop(route)
        adapter = gw._adapter_for_source(src)
        async def complete():
            try:
                if refused: msg = '其他聊天仍有绑定；没有关闭入口。'
                elif action == '关闭':
                    if runner:await self._stop_host()
                    msg = '清理未确认；请在 Unity 本地检查。' if self.failed else '接收入口已关闭。'
                elif chat:
                    await finish(chat.task)
                    msg = '已停止本聊天的连接。'
                else:msg = '本聊天没有活跃连接。'
            except Exception:
                self.failed = True
                msg = '已请求撤权，但清理未确认；请在 Unity 本地检查。'
            if (not self.closing and route in self.routes and gw._adapter_for_source(src) is adapter
                    and adapter is not None and gw._is_user_authorized_for_source(src) is True
                    and (src.platform.value,src.user_id,src.chat_id,src.profile,src.thread_id)==route
                    and src.chat_type=='dm' and not src.is_bot and not src.profile_route_rejected):
                await adapter.send(src.chat_id,msg,reply_to=mid,metadata=gw._thread_metadata_for_source(src,mid))
        task = self.ctx.spawn_task(complete(),name='candidate-control')
        self.controls[key] = task
        task.add_done_callback(lambda _: self.controls.pop(key,None))

    async def _serve(self):
        try:
            async with ChatHost(self.path, include=self.include, **({'middleware_ctx':self.ctx} if self.image_egress else {})) as host:
                self.host = host
                self.ready.set()
                try:
                    async with asyncio.timeout(3600):
                        await self.stop.wait()
                except TimeoutError:
                    pass
        except asyncio.CancelledError:
            if not self.closing:
                self.failed = True
            raise
        except BaseException:
            self.failed = True
            raise
        finally:
            self.host = None
            self.ready.set()

    async def _stop_host(self):
        if self.stop is not None:
            self.stop.set()
        runner=self.runner
        if runner is not None:
            try:
                results = await finish(asyncio.gather(runner, return_exceptions=True))
                if any(isinstance(value, BaseException) and not
                       (isinstance(value, asyncio.CancelledError) and self.closing) for value in results):
                    raise RuntimeError('candidate_plugin_cleanup_failed')
            except BaseException:
                self.failed = True
                raise
            finally:
                if self.runner is runner and runner.done():
                    self.runner = None

    async def _request(self, route, args, source, message_id, gateway, *, owner=None, pinned=None, generation=None):
        from .hermes_read import session
        natural_input = owner is not None
        def gw_adapter():return gateway._adapter_for_source(source)
        adapter = gw_adapter()
        if adapter is None:
            return
        def authorized():
            return (not self.closing and generation==(self.generation,self.stop_epoch.get(route,0))
                    and gw_adapter() is adapter and route in self.routes and source.chat_type == 'dm'
                    and not source.profile_route_rejected and not source.is_bot
                    and (source.platform.value, source.user_id, source.chat_id, source.profile, source.thread_id) == route
                    and gateway._is_user_authorized_for_source(source) is True
                    and (not pinned or session(gateway,source)==pinned)
                    and (not natural_input or (self.stop_epoch.get(route, 0) == owner[2]
                         and not natural.host_controls_input(gateway, source))))
        async def reply(text):
            if not authorized():
                return
            result = await adapter.send(source.chat_id, text, reply_to=message_id,
                metadata=gateway._thread_metadata_for_source(source, message_id))
            if not result.success:
                raise RuntimeError('candidate_reply_failed')
        try:
            if not authorized():
                return
            if natural_input and (self.host is not owner[0] or
                    (self.host is not None and self.host.chats.get(route) is not owner[1])):
                return
            action = args.split(' ', 1)[0]
            if args == '开始':
                if any(action=='关闭' for _,action in self.controls):
                    await reply('入口正在关闭；请等待清理完成。')
                    return
                if self.failed:
                    await reply('清理或启动未确认；入口保持关闭，需本地检查。')
                    return
                if self.runner is None:
                    self.stop = asyncio.Event()
                    self.ready = asyncio.Event()
                    self.runner = self.ctx.spawn_task(self._serve(), name='candidate-receiver')
                await self.ready.wait()
                if self.host is None:
                    await self._stop_host()
                    raise RuntimeError('candidate_receiver_unavailable')
                await reply('接收入口已开启，最长一小时；请在 Unity 手动连接，再说「连接 Unity 工程」。没有授予任务权限。' if self.read else '接收入口已开启；在 Unity 手动连接后使用 /vrc 列表。')
            elif self.host is None:
                await reply(natural.OPEN_HINT if natural_input else '入口未开启；使用 /vrc 开始。')
            elif natural_input and pinned==():
                await reply('尚未确认当前私聊会话；请先建立普通会话，再选择工程。没有连接 Unity。')
            elif natural_input:
                await self.host.natural_command(route, args, reply=reply, authorized=authorized, owner_session=pinned)
            else:
                options = {}
                if not self.read and action == '绑定':
                    model, runtime = gateway._resolve_session_agent_runtime(source=source)
                    options = {**runtime,'model':model,'quiet_mode':True,'verbose_logging':False,
                        'fallback_model':None,'max_iterations':20,'platform':route[0],
                        'user_id':route[1],'chat_id':route[2],'chat_type':'dm'}
                await self.host.command(route,args,options=options,reply=reply)
        except asyncio.CancelledError:
            raise
        except Exception:
            try:
                await reply('候选操作失败；不会自动重试。若清理未确认，请在 Unity 停止连接。')
            except Exception:
                pass  # platform failure is not permission to send elsewhere

    def request_close(self):
        self.closing = True
        if self.host is not None:
            for route in tuple(self.host.chats):
                self.host.request_stop(route)
        if self.stop is not None:
            self.stop.set()

    async def close(self):
        self.request_close()
        try:
            await self._stop_host()
        finally:
            tasks = self.pending.union(self.controls.values())
            if tasks:await finish(asyncio.gather(*tasks, return_exceptions=True))
