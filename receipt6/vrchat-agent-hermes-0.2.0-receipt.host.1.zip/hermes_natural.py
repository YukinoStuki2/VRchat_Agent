"""Literal QQ C2C intents. No classifier, history, model, transport or startup I/O."""
import re

OPEN_HINT = '入口未开启。如要接收本地工程连接，请说「打开 Unity 接收入口」。'


def intent(text):
    if not 0 < len(text) <= 220 or not text.isprintable():
        return None
    phrase = re.sub(r'^(?:巧克力[，,] *|请 *){0,2}', '', text.strip()).rstrip('。？?')
    patterns = (
        (r'(?:打开|开启) *Unity *接收入口', '开始'),
        (r'(?:连接|查看|列出) *(?:可连接的)?Unity *(?:工程|项目)', '列表'),
    )
    for pattern, action in ((r'(?:绑定|连接) *Unity *(?:工程|项目) +([A-Za-z0-9_-]{1,128})', 'project'),
                            (r'绑定 *Unity *连接 +([0-9a-f]{32})', 'offer')):
        match = re.fullmatch(pattern, phrase)
        if match:
            return action + ' ' + match[1]
    for pattern, action in patterns:
        if re.fullmatch(pattern, phrase, flags=re.IGNORECASE | re.ASCII):
            return action
    return None


# A closed grammar, not a keyword search: every clause has to be a read.
# Evaluated only within an explicitly selected Unity binding. Never parse history.
_POLITE = r'(?:(?:巧克力[,，]?|麻烦你?|能不能|能否|可以|请你?|帮我|给我|我想知道|告诉我|把|再|并|顺便))*'
_LOOK = r'(?:(?:看(?:一?下|看)?|查(?:一?下|看)?|列(?:一?下|出来?|举)?|显示|说说|读(?:取)?|告诉我|报一下|展示)(?:一下)?(?:我)?)?'
_DOMAIN = r'(?:(?:在|我)?(?:unity(?:编辑器|工程|项目)?|编辑器)(?:里|中|内)?(?:的)?)?'
_NOW = r'(?:我)?(?:现在|当前|正在|目前)?(?:所)?'
_OPEN = r'(?:打开|编辑|激活|活动|使用|在做|做)(?:着|中)?(?:的)?'
_SCENE = re.compile(_POLITE + _LOOK + _NOW + _DOMAIN + _NOW + r'(?:' + _OPEN +
    r'(?:的是|是)?(?:哪一?(?:个|张)|什么)(?:场景|地图)|(?:'+_OPEN+r')?(?:场景(?:名(?:称|字)?)?)(?:是(?:哪个|什么)|叫(?:什么(?:名字)?|啥)|名称|名(?:称|字)?(?:是什么)?)|'+
    r'(?:是)?(?:哪一?个|什么)场景|(?:'+_OPEN+r')场景(?:的)?(?:名(?:称|字)?)?|(?:活动|当前)场景|哪(?:个|一?张)(?:场景|地图)(?:正)?(?:在)?(?:打开|编辑))' + r'(?:吗|呢)?')
_ROOT = re.compile(_POLITE + _LOOK + _NOW + _DOMAIN + _NOW + r'(?:场景(?:中|里|的)?)?(?:(?:hierarchy|层级)(?:面板|窗口|视图|树)?(?:里|中)?(?:的)?)?'
    r'(?:前(?:五|5)个)?(?:第一层|最(?:上面|上层|顶层)|顶层|根层(?:级)?|根)(?:里|中|的)?(?:挂(?:着|了))?(?:都有|都|有)?(?:哪(?:些|几个)|什么)?'
    r'(?:(?:最多|只看)?前?(?:五|5)个)?(?:物体|对象|节点)(?:的)?(?:名(?:称|字)?)?(?:有(?:哪些|什么)|是哪些)?(?:吗|呢)?')
_EN_SCENE = re.compile(r'(?:what(?:\'s| is)|which|show(?: me)?|name|list|tell me) (?:the |my )?(?:(?:current|active|open|unity|currently open) )+(?:scene|level)(?: name)?(?: in unity)?|which (?:unity scene|unity level|scene) (?:am i editing|is open)(?: in unity)?')
_EN_ROOT = re.compile(r'(?:list|show(?: me)?|what are) (?:the )?(?:first (?:five|5) )?(?:unity |scene |hierarchy )?(?:roots|root (?:objects|names)|top[- ]level objects)(?: in (?:the hierarchy|unity))?')


def read_view(text):
    if type(text) is not str or not 0 < len(text) <= 220 or not text.isprintable():return None
    text=text.strip().lower().rstrip('。？?!！. ')
    # A selected project alone does not turn a vague question about a film,
    # shelf, game level, etc. into a Unity query. A clear second clause may
    # share its first clause's explicit editor context (never an older turn).
    if not re.search(r'unity|hierarchy|编辑器|层级|当前场景名|(?:打开|编辑|活动|激活)(?:的)?(?:是(?:哪一?个|什么))?场景|scene (?:roots|is open)|(?:active|open) scene',text):return None
    clauses=re.split(r'(?:[，,。？?；;]+\s*|\s+and\s+|以及|并且|顺便|同时|还有|和)',text)
    views=set()
    for clause in clauses:
        if clause in ('巧克力',''):continue
        cn=clause.replace(' ','')
        if _SCENE.fullmatch(cn) or _EN_SCENE.fullmatch(clause.strip()):views.add('scene')
        elif _ROOT.fullmatch(cn) or _EN_ROOT.fullmatch(clause.strip()):views.add('roots')
        else:return None
    return 'both' if len(views)==2 else next(iter(views),None)


def display_name(value):
    if type(value) is not str or not 0 < len(value) <= 256 or not value.isprintable():
        raise ValueError('invalid_name')
    return value


def host_controls_input(gateway, source):
    # This prestage runs before busy/control and pause handling. Observe, never
    # resolve, consume, acknowledge or rewrite an existing control prompt.
    from agent.estop import paused_reply
    from tools import clarify_gateway, slash_confirm
    from tools.approval import has_blocking_approval
    key = gateway._session_key_for_source(source)
    state = gateway._peek_session_state(key)
    return (not key or paused_reply() is not None or gateway._is_session_running(key)
            or (state is not None and state.persistent.update_prompt_pending)
            or clarify_gateway.has_pending(key) or has_blocking_approval(key)
            or slash_confirm.get_pending(key) is not None)


def direct_qq_text(event, source):
    """QQ folds quotes/media into text. Accept only matching original C2C text."""
    raw = getattr(event, 'raw_message', None)
    if type(raw) is not dict or type(raw.get('author')) is not dict:
        return False
    return (getattr(event.message_type, 'value', None) == 'text'
            and event.internal is False and event.allow_gateway_control is True
            and not any((event.reply_to_message_id, event.reply_to_text, event.reply_to_author_id,
                         event.reply_to_author_name, event.reply_to_is_own_message, event.media_urls,
                         event.media_types, event.prompt_response is not None, event.inherit_channel_pin,
                         event.channel_context, event.edit_revision, event.metadata, source.is_bot))
            and bool(event.message_id) and raw.get('id') == event.message_id
            and type(raw.get('content')) is str and raw['content'].strip() == event.text
            and raw['author'].get('user_openid') == source.user_id == source.chat_id
            and not raw['author'].get('bot') and raw.get('message_type', 0) in (0, '0')
            and not raw.get('attachments') and not raw.get('msg_elements')
            and not {'message_reference','referenced_message','guild_id','group_openid','interaction'} & raw.keys())
