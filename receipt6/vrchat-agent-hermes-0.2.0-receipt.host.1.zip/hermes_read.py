"""One fixed host tool, one consumable plan. Receipt-only wait; no chat/model text on MCP."""
import asyncio
import hashlib
import json
import re
import secrets
import time
from . import hermes_natural as natural

VIEWS = {'scene': ('get_active',), 'roots': ('get_hierarchy',), 'both': ('get_active','get_hierarchy')}
TTL = 90
POLL = 1.0
NAME = 'vrc_scene_read'
DENIED = '{"error":"no_current_bound_owner_read"}'

def route(src):
    return src.platform.value, src.user_id, src.chat_id, src.profile, src.thread_id

def direct(event, gateway):
    # Native adapter callback capability; matching JSON alone is not proof.
    from gateway.session_ingress_context import _callback
    proof = _callback.get()
    s = event.source
    return (proof and proof[0] is gateway and proof[1] is event and s.platform.value == 'qqbot'
            and not s.delivered_via_upstream_relay and s.chat_type == 'dm' and not s.profile_route_rejected
            and event.user_id in (None,s.user_id) and type(event.message_id) is str and len(event.message_id)<=256
            and not any((event.auto_skill,event.reply_anchor_override,event.ledger_message_id))
            and natural.direct_qq_text(event,s))

def dm_adapter(gw, src):
    adapter = gw._intake_adapter_for(src)
    if (adapter is not None and gw._adapter_for_source(src) is adapter
            and getattr(adapter,'_chat_type_map',{}).get(src.chat_id)=='c2c'):
        return adapter
    return None

def session(gw, src):
    key = gw._session_key_for_source(src)
    sid = gw.session_store.peek_session_id(key)
    if not key or type(sid) is not str or not sid:
        raise ValueError('no established session')
    return key,sid

def digest(text):
    return hashlib.sha256(text.encode()).digest()

async def data(binding, name, args):
    async with asyncio.timeout(10):
        obj=json.loads(await binding._call(name,args,binding._conversation))
    mcp=obj['mcp']; p=mcp['structuredContent']
    if ('error' in obj or mcp.get('isError') is not False or type(p) is not dict
            or p.get('success') is not True or type(p.get('data')) is not dict):
        raise ValueError('unconfirmed')
    return p['data']

class ReadFacade:
    def __init__(self, plugin, ctx):
        self.plugin=plugin
        self.loop=None
        ctx.register_tool(name=NAME,toolset='vrchat-agent-candidate',schema={'name':NAME,
            'description':'Only for a user asking about the currently bound Unity project. Request its active scene name, up to five hierarchy root names, or both together. Not for general conversation. Pending is not a read result: ask only for local approval. The host replies automatically; do not call again.',
            'parameters':{'type':'object','properties':{'view':{'type':'string','enum':list(VIEWS)}},
                          'required':['view'],'additionalProperties':False}},handler=self.tool)

    def observe(self, gw, event, chat):
        # Last direct event only. Keep a digest, not the QQ text. Never evict a
        # consumed ID to make room for replay within this binding.
        self.loop=asyncio.get_running_loop()
        chat.ticket=None
        view = natural.read_view(event.text)
        adapter = dm_adapter(gw,event.source) if view else None
        if (adapter is None or chat.owner_session != session(gw,event.source) or len(chat.seen)>=2048
                or event.message_id in chat.seen or len(event.text)>8192):return
        chat.seen.add(event.message_id)
        chat.ticket=(gw,event.message_id,digest(event.text),time.monotonic()+TTL,view,event.source,adapter)

    def tool(self,args,*,session_id=None,task_id=None,**unused):
        from gateway import session_context as sc
        from tools import approval_context as ac
        from agent.delegation_context import is_delegated_child_context
        if (type(args) is not dict or set(args)!={'view'} or type(args['view']) is not str or args['view'] not in VIEWS
                or is_delegated_child_context() or not session_id or task_id!=session_id or self.loop is None
                or ac._approval_session_id.get()!=session_id or not ac._approval_tool_call_id.get()):return DENIED
        # Read actual contextvars only: never use get_session_env's os.environ fallback.
        r=(sc._SESSION_PLATFORM.get(),sc._SESSION_USER_ID.get(),sc._SESSION_CHAT_ID.get(),
           sc._SESSION_PROFILE.get() or None,sc._SESSION_THREAD_ID.get() or None)
        key=sc.bound_session_key(); tid=ac._approval_turn_id.get()
        if (not tid or not key or r not in self.plugin.routes or sc._SESSION_CHAT_TYPE.get()!='dm'
                or sc._SESSION_ID.get()!=session_id or sc._CRON_SESSION.get()!=''):return DENIED
        try:
            if asyncio.get_running_loop() is self.loop:return DENIED
        except RuntimeError:pass
        coro=self.prepare(r,key,session_id,tid,args['view'])
        try:fut=asyncio.run_coroutine_threadsafe(coro,self.loop)
        except RuntimeError:coro.close();return DENIED
        try:return fut.result(13)
        except Exception:fut.cancel();return DENIED

    def current(self, r, chat, gw, src):
        p=self.plugin; h=p.host
        return (not p.closing and h and not h.closing and not h.cleanup_failed and h.chats.get(r) is chat
            and chat.natural and chat.binding and not chat.stop.is_set() and h.receiver.live(chat.offer,chat.binding)
            and not src.delivered_via_upstream_relay and r in p.routes and route(src)==r and src.chat_type=='dm' and not src.is_bot and not src.profile_route_rejected
            and gw._is_user_authorized_for_source(src) is True and session(gw,src)==chat.owner_session)

    async def prepare(self,r,key,sid,tid,view):
        chat=self.plugin.host.chats.get(r) if self.plugin.host else None
        if not chat or not chat.ticket or chat.owner_session!=(key,sid):return DENIED
        ticket=chat.ticket
        gw,mid,hashed,until,requested,src,adapter=ticket
        if view != requested:return DENIED
        binding=chat.binding
        def bound():
            return (chat.owner_session==(key,sid) and chat.binding is binding and self.current(r,chat,gw,src)
                    and dm_adapter(gw,src) is adapter)
        def live():
            slot=gw._peek_session_state(key).turn; e=slot.event; c=slot.ctx; a=slot.agent
            return (chat.ticket is ticket and bound() and self.current(r,chat,gw,e.source) and time.monotonic()<until and not e.internal and e.allow_gateway_control
                and e.message_id==c.inbound_message_id==a._persist_user_message_platform_id==mid
                and not e.reply_anchor_override and not e.ledger_message_id and digest(e.text)==hashed
                and c.session_key==key and c.session_id==a.session_id==sid and c._run_still_current()
                and a.platform=='qqbot' and not getattr(a,'_parent_session_id',None) and not getattr(a,'_turn_origin',None)
                and a._inflight_turn_id==a._current_turn_id==tid and not a._interrupt_requested and route(c.source)==r)
        if not live() or chat.read_busy:return DENIED
        if chat.used==mid:return DENIED
        chat.used=mid
        if chat.worker and not chat.worker.done():return '{"error":"another_plan_pending"}'
        chat.read_busy=True
        try:
            task_id='read-'+secrets.token_hex(12)
            deadline=time.monotonic()+TTL
            d=await data(binding,'agent_prepare',{'task_id':task_id,'ttl_seconds':TTL,'targets':['Scenes'],
                'operations':[{'command':'manage_scene','action':op} for op in VIEWS[view]]})
            plan_id=d.get('plan_id')
            if (d.get('status')!='pending' or d.get('task_id',task_id)!=task_id or type(plan_id) is not str
                    or not re.fullmatch('[a-zA-Z0-9_-]{1,128}',plan_id) or not live()):return DENIED
            plan=(task_id,plan_id,deadline)
            chat.plan=plan
            chat.worker=self.plugin.ctx.spawn_task(self.wait_for_approval(chat,plan,view,binding,bound,gw,src,adapter,mid),name='candidate-receipt')
            return json.dumps({'status':'pending','instructions':'请在 Unity 核对并批准本次读取。批准后会自动回复这条私聊，无需再发消息。'},ensure_ascii=False)
        except (ValueError,KeyError,TypeError,TimeoutError):
            return '{"error":"没有取得待批准清单；请检查 Unity 本地读取权限和版本。"}'
        finally:chat.read_busy=False

    async def wait_for_approval(self,chat,plan,view,binding,bound,gw,src,adapter,mid):
        task_id,plan_id,deadline=plan
        ids={'task_id':task_id,'plan_id':plan_id}
        def live():
            return chat.plan is plan and time.monotonic()<deadline and bound()
        async def status():
            if not live():return None
            d=await data(binding,'agent_scene_receipt',ids)
            if not live() or set(d)!=set(ids)|{'status'} or any(d[k]!=v for k,v in ids.items()):return None
            return d['status']
        try:
            async with asyncio.timeout(max(0,deadline-time.monotonic())):
                while live():
                    await asyncio.sleep(POLL)
                    state=await status()
                    if state=='approved':break
                    if state!='pending':return
                else:return
                out={}
                for op in VIEWS[view]:
                    if not live():return
                    args={'action':op}
                    if op=='get_hierarchy':args['page_size']=5
                    d=await data(binding,'manage_scene',args)
                    if not live():return
                    if op=='get_active':out['当前场景']=natural.display_name(d['name'])
                    else:
                        if d.get('scope')!='roots' or type(d.get('items')) is not list or len(d['items'])>5:return
                        out['层级根对象']=[natural.display_name(x['name']) for x in d['items']]
                    # A local supersession while the read was in flight vetoes
                    # the next operation AND delivery. Never retry an execution.
                    if await status()!='approved':return
                if live():
                    await adapter.send(src.chat_id,json.dumps(out,ensure_ascii=False),reply_to=mid,
                        metadata=gw._thread_metadata_for_source(src,mid))
        except Exception:
            return  # malformed, withdrawn, timed out or delivery unknown: no retry/fallback
        finally:
            if chat.plan is plan:chat.plan=None
