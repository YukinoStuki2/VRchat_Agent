using System;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Yukino.VRChatAgent
{
    // Single existing C#/Shader file exception. Editor-thread policy, not a plugin
    // sandbox. A caller must supply locally accepted live plugin-context evidence.
    // No remote approve/restore/compile endpoint and no grant persistence.
    internal sealed class ScriptWriteGate
    {
        sealed class Plan
        {
            internal string Id,Digest,Project,Connection,Client,Task,Target,Context;
            internal double Expires;
            internal bool Approved;
            internal JObject Evidence,Manifest,LastReceipt;
        }
        readonly Func<double> clock;
        readonly Func<string> project,connection,context;
        readonly ScriptFileStore store;
        Plan plan;
        readonly Dictionary<string,Plan> history=new Dictionary<string,Plan>();
        readonly Dictionary<string,JObject> diagnostics=new Dictionary<string,JObject>();
        bool enabled,compileEnabled,busy;
        long generation;
        double lastTime=double.NegativeInfinity;
        internal string LastReason {get;private set;}="单文件写入与导入/编译效果均默认关闭";
        internal ScriptWriteGate(Func<double> clock,Func<string> project,Func<string> connection,Func<string> context,ScriptFileStore store)
        {this.clock=clock;this.project=project;this.connection=connection;this.context=context;this.store=store;}
        static void Need(bool ok,string reason){if(!ok)throw new CandidateWriteDenied(reason);}
        static void Keys(JObject obj,params string[] keys)=>Need(obj!=null&&obj.Count==keys.Length&&obj.Properties().All(p=>keys.Contains(p.Name)),"unexpected_fields");
        static string Text(JToken token)
        {
            Need(token?.Type==JTokenType.String,"invalid_string");string value=(string)token;
            Need(value.Length>0&&value.Length<=512&&value==value.Trim()&&!value.Any(char.IsControl),"invalid_string");return value;
        }
        static bool Digest(string value)=>value!=null&&value.Length==64&&value.All(c=>"0123456789abcdef".Contains(c));
        static JObject Ok(JObject data)=>new JObject{["success"]=true,["data"]=data};
        static JObject Fail(string reason,JObject data=null)=>new JObject{["success"]=false,["error"]=reason,["data"]=data??new JObject{["status"]="denied"}};
        double Now()
        {
            double now=clock();Need(!double.IsNaN(now)&&!double.IsInfinity(now)&&now>=lastTime,"invalid_clock");lastTime=now;return now;
        }
        internal void StopAll(string reason){generation++;plan=null;LastReason=reason;}
        internal bool Enabled=>enabled;
        internal bool CompileEnabled=>compileEnabled;
        internal void SetCapability(bool value){enabled=value;if(!value)StopAll("单文件写入已撤权；不自动回退");}
        internal void SetCompileCapability(bool value){compileEnabled=value;if(!value)StopAll("导入/编译效果已撤权；不自动回退");}
        void Current(Plan expected,bool approved)
        {
            Need(expected!=null&&ReferenceEquals(plan,expected),"plan_not_current");long epoch=generation;
            Need(enabled&&compileEnabled,"capability_disabled");Need(!approved||expected.Approved,"local_approval_required");
            Need(Now()<expected.Expires&&expected.Project==project()&&expected.Connection==connection()&&expected.Connection.Length>0,"binding_or_expiry_changed");
            Need(expected.Context==context()&&epoch==generation&&ReferenceEquals(plan,expected),"plugin_context_changed");
        }
        void Verify(Plan expected)
        {Current(expected,false);Need(JToken.DeepEquals(store.Capture(expected.Target),expected.Evidence),"relevant_evidence_changed");Current(expected,false);}
        internal void Observe()
        {if(plan==null)return;try{Current(plan,false);}catch{StopAll("绑定、插件前提或期限失效；保留现场");}}
        internal JArray LocalPlans()
        {
            Observe();var p=plan;return p==null?new JArray():new JArray(new JObject{["plan_id"]=p.Id,["digest"]=p.Digest,
                ["project_id"]=p.Project,["connection_id"]=p.Connection,["client_id"]=p.Client,["task_id"]=p.Task,
                ["approved"]=p.Approved,["manifest"]=p.Manifest.DeepClone(),["evidence"]=p.Evidence.DeepClone()});
        }
        internal bool Approve(string id,string digest)=>ApproveChecked(id,digest,null);
        internal bool ApproveContinuation(string id,string digest,string transaction)=>ApproveChecked(id,digest,transaction);
        bool ApproveChecked(string id,string digest,string transaction)
        {
            var p=plan;if(busy||p==null||p.Approved||p.Id!=id||p.Digest!=digest)return false;
            busy=true;try
            {
                Verify(p);
                if(transaction!=null)
                {
                    var receipt=store.LocalTransaction(transaction,true);
                    Need((string)receipt["target"]==p.Target&&new[]{"changed","restored"}.Contains((string)receipt["outcome"])&&
                        receipt["error"]?.Type==JTokenType.Null,"continuation_history_unconfirmed");
                    var expected=new JObject{["sha256"]=receipt[(string)receipt["outcome"]=="restored"?"before_sha256":"expected_after_sha256"],
                        ["meta_sha256"]=receipt["meta_sha256"]};
                    Need(JToken.DeepEquals(expected,p.Evidence),"continuation_postimage_changed");
                    Verify(p);
                }
                Current(p,false);p.Approved=true;LastReason="本地已批准单文件例外及导入/编译效果";return true;
            }
            catch{StopAll("批准前证据变化；未授权");return false;}finally{busy=false;}
        }
        internal JArray LocalHistory()=>store.History();
        internal static JObject CompilationSubject(JObject transaction)
        {
            string state=(string)transaction?["outcome"];
            if(state!="changed"&&state!="restored")return null;
            return new JObject{["transaction_id"]=transaction["transaction_id"],["target"]=transaction["target"],
                ["phase"]=state=="restored"?"restore_preimage":"write_postimage",
                ["sha256"]=transaction[state=="restored"?"before_sha256":"expected_after_sha256"],
                ["meta_sha256"]=transaction["meta_sha256"]};
        }
        internal const int CompilationObservationBytes=4096;
        internal const int DiagnosticEnvelopeBytes=4*1024*1024;
        static readonly string[] CompilationStates={"compiling","failed_preserved","compile_finished_reload_unverified",
            "shader_errors_preserved","shader_import_no_reported_errors"};
        static JObject ObservationFor(JObject subject,string state,int errors)
        {
            Need(subject!=null&&CompilationStates.Contains(state)&&errors>=0&&errors<=100000,"invalid_compilation_observation");
            bool shader=state.StartsWith("shader_",StringComparison.Ordinal);
            var row=new JObject{["state"]=state,["error_count"]=errors,
                ["diagnostic_scope"]=shader?"target_shader_import":"project_compilation",
                [shader?"all_variants_verified":"caused_by_this_edit_proven"]=false,
                ["reload_verified"]=false,["automatic_rollback"]=false,["subject"]=subject.DeepClone(),
                ["source_binding"]="expected_input_not_compiler_attestation"};
            Need(System.Text.Encoding.UTF8.GetByteCount(row.ToString(Formatting.None))<=CompilationObservationBytes,"diagnostic_budget");
            return row;
        }
        internal static JObject CompilationObservation(JObject transaction,string state,int errors)=>
            ObservationFor(CompilationSubject(transaction),state,errors);
        static void CheckObservation(JObject subject,JObject observation)
        {
            Need(observation!=null&&observation["state"]?.Type==JTokenType.String&&
                observation["error_count"]?.Type==JTokenType.Integer&&(long)observation["error_count"]>=0&&
                (long)observation["error_count"]<=100000&&JToken.DeepEquals(subject,observation["subject"]),"invalid_diagnostic_history");
            var canonical=ObservationFor(subject,(string)observation["state"],(int)observation["error_count"]);
            Need(JToken.DeepEquals(canonical,observation),"invalid_diagnostic_history");
        }
        static void ReserveDiagnostics(string target)
        {
            // Same encoder/schema as active observations and loading, before effects.
            // 512 UTF-16 units at <=6 JSON bytes, plus 1024 identity bytes and four
            // <=4096-byte observations per transaction: 128 records + 64KiB display
            // reserve fit the shared 4MiB envelope. Subject identity is never truncated.
            ScriptFileStore.Target(target);
            var receipt=new JObject{["transaction_id"]=new string('f',32),["target"]=target,
                ["before_sha256"]=new string('f',64),["expected_after_sha256"]=new string('f',64),
                ["meta_sha256"]=new string('f',64)};
            foreach(string outcome in new[]{"changed","restored"})
            {
                receipt["outcome"]=outcome;
                foreach(string state in CompilationStates)CompilationObservation(receipt,state,100000);
            }
        }
        internal static bool ApplyCompilation(JObject data,JObject observation)
        {
            var expected=CompilationSubject(data?["transaction"] as JObject);
            if(expected==null||!JToken.DeepEquals(expected,observation?["subject"]))return false;
            CheckObservation(expected,observation);
            data["compilation"]=observation.DeepClone();data["compilation_verified"]=false;
            if((int?)observation["error_count"]>0&&data["first_failed_compilation"]==null)
                data["first_failed_compilation"]=observation.DeepClone();
            return true;
        }
        static bool SameTransaction(JToken left,JToken right)=>left is JObject&&right is JObject&&
            new[]{"transaction_id","target","before_sha256","expected_after_sha256","meta_sha256"}.All(k=>
                left[k]?.Type==JTokenType.String&&JToken.DeepEquals(left[k],right[k]));
        static void InheritFailure(JObject data,JObject prior)
        {
            var subject=CompilationSubject(data?["transaction"] as JObject);
            var failure=prior?["first_failed_compilation"];
            if(subject!=null&&SameTransaction(data["transaction"],prior?["transaction"])&&
                JToken.DeepEquals(subject,failure?["subject"]))data["first_failed_compilation"]=failure.DeepClone();
        }
        static JObject DiagnosticSnapshot(JObject data)
        {
            var transaction=data?["transaction"] as JObject;var subject=CompilationSubject(transaction);
            Need(subject!=null&&Guid.TryParseExact((string)transaction["transaction_id"],"N",out _),"invalid_diagnostic_history");
            ReserveDiagnostics((string)transaction["target"]);
            var identity=new JObject();
            foreach(string key in new[]{"transaction_id","target","before_sha256","expected_after_sha256","meta_sha256","outcome"})
            {Need(transaction[key]?.Type==JTokenType.String,"invalid_diagnostic_history");identity[key]=transaction[key].DeepClone();}
            foreach(string key in new[]{"before_sha256","expected_after_sha256","meta_sha256"})Need(Digest((string)identity[key]),"invalid_diagnostic_history");
            var snapshot=new JObject{["transaction"]=identity};
            foreach(string key in new[]{"compilation","first_failed_compilation"})
            {
                if(data[key]==null)continue;
                var observation=data[key] as JObject;
                CheckObservation(subject,observation);
                Need(key!="first_failed_compilation"||(long)observation["error_count"]>0,"invalid_diagnostic_history");
                snapshot[key]=observation.DeepClone();
            }
            return snapshot;
        }
        internal JArray ExportDiagnostics()
        {
            var rows=new JArray();
            foreach(var item in diagnostics.OrderBy(x=>x.Key,StringComparer.Ordinal))
            {
                var row=new JObject();foreach(var phase in item.Value.Properties())row[phase.Name]=DiagnosticSnapshot(phase.Value as JObject);
                rows.Add(row);
            }
            return rows;
        }
        internal void LoadDiagnostics(JArray rows)
        {
            Need(rows!=null&&rows.Count<=128,"diagnostic_capacity");
            var loaded=new Dictionary<string,JObject>();
            foreach(var token in rows)
            {
                var row=token as JObject;Need(row!=null&&row.Count>0&&row.Count<=2,"invalid_diagnostic_history");
                var clean=new JObject();string id=null;JToken first=null;
                foreach(var phase in row.Properties())
                {
                    Need(phase.Name=="write_postimage"||phase.Name=="restore_preimage","invalid_diagnostic_history");
                    var snapshot=DiagnosticSnapshot(phase.Value as JObject);
                    Need((string)CompilationSubject(snapshot["transaction"] as JObject)["phase"]==phase.Name,"invalid_diagnostic_history");
                    if(first!=null)Need(SameTransaction(first,snapshot["transaction"]),"invalid_diagnostic_history");
                    first=snapshot["transaction"];id=(string)first["transaction_id"];clean[phase.Name]=snapshot;
                }
                Need(!loaded.ContainsKey(id),"invalid_diagnostic_history");loaded.Add(id,clean);
            }
            Need(diagnostics.Count==0,"diagnostic_history_already_loaded");
            foreach(var row in loaded)diagnostics.Add(row.Key,row.Value);
        }
        void CheckDiagnosticIdentity(JObject transaction)
        {
            string id=(string)transaction?["transaction_id"];
            if(id!=null&&diagnostics.TryGetValue(id,out var row))
                foreach(var phase in row.Properties())
                    Need(SameTransaction(phase.Value["transaction"],transaction),"diagnostic_identity_conflict");
        }
        void Remember(JObject data)
        {
            var subject=CompilationSubject(data?["transaction"] as JObject);if(subject==null)return;
            CheckDiagnosticIdentity(data["transaction"] as JObject);
            string id=(string)subject["transaction_id"],phase=(string)subject["phase"];
            if(!diagnostics.TryGetValue(id,out var row))
            {Need(diagnostics.Count<128,"diagnostic_capacity");diagnostics[id]=row=new JObject();}
            InheritFailure(data,row[phase] as JObject);row[phase]=DiagnosticSnapshot(data);
        }
        void AttachRecovery(JObject data)
        {
            var transaction=data["transaction"];string id=(string)transaction["transaction_id"];
            if(diagnostics.TryGetValue(id,out var row))
            {
                string phase=(string)CompilationSubject(transaction as JObject)?["phase"];
                if(phase!=null)InheritFailure(data,row[phase] as JObject);
                if(phase=="restore_preimage"&&row["write_postimage"] is JObject original&&SameTransaction(transaction,original["transaction"]))
                {data["write_receipt"]=original.DeepClone();data["write_receipt"]["receipt_is_historical"]=true;data["write_receipt"]["compilation_verified"]=false;}
            }
            if((string)transaction["outcome"]!="restored")return;
            foreach(var p in history.Values)
                if(SameTransaction(p.LastReceipt?["transaction"],transaction))p.LastReceipt["recovery_receipt"]=data.DeepClone();
        }
        internal void ObserveCompilation(string transaction,JObject observation)
        {
            // Historical observation only; a restore can never rewrite its write phase.
            if(transaction!=null&&diagnostics.TryGetValue(transaction,out var phases))
                foreach(var phase in phases.Properties())ApplyCompilation(phase.Value as JObject,observation);
            foreach(var p in history.Values)
            {
                if((string)p.LastReceipt?["transaction"]?["transaction_id"]!=transaction)continue;
                bool applied=ApplyCompilation(p.LastReceipt,observation);
                if(p.LastReceipt["recovery_receipt"] is JObject recovery)applied=ApplyCompilation(recovery,observation)||applied;
                if(applied&&ReferenceEquals(plan,p))StopAll("已观察编译生命周期；保留修改，原授权不自动恢复");
            }
        }
        JObject Status(string client,string task,string id)
        {
            Observe();
            if(id=="")return Ok(new JObject{["status"]="capabilities",["write_enabled"]=enabled,["compile_enabled"]=compileEnabled,["grant_active"]=false});
            Need(history.TryGetValue(id,out var p)&&p.Client==client&&p.Task==task&&p.Project==project()&&p.Connection==connection(),"plan_not_current");
            return Ok(new JObject{["status"]=ReferenceEquals(plan,p)?p.Approved?"approved":"pending":"stopped",
                ["grant_active"]=ReferenceEquals(plan,p)&&p.Approved,["plan_id"]=p.Id,
                ["receipt_is_historical"]=true,["last_receipt"]=p.LastReceipt==null?JValue.CreateNull():(JToken)p.LastReceipt.DeepClone()});
        }
        // Local UI only; no network dispatch kind can enter this method.
        internal JObject ImportLocal(string id,Action<JObject,Func<bool>> import)
        {
            if(busy)return Fail("execution_in_progress");busy=true;
            StopAll("本地批准精确单文件导入；旧编辑授权不恢复");long epoch=generation;
            JObject data=null;
            try
            {
                string expectedProject=project(),expectedContext=context();
                Need(enabled&&compileEnabled&&Digest(expectedContext),"local_import_effect_consent_required");
                Need(diagnostics.ContainsKey(id)||diagnostics.Count<128,"diagnostic_capacity");
                var receipt=store.LocalTransaction(id);CheckDiagnosticIdentity(receipt);ReserveDiagnostics((string)receipt["target"]);
                Need(new[]{"changed","restored"}.Contains((string)receipt["outcome"])&&receipt["error"]?.Type==JTokenType.Null,"transaction_not_importable");
                string target=(string)receipt["target"];
                var expected=new JObject{["sha256"]=receipt[(string)receipt["outcome"]=="restored"?"before_sha256":"expected_after_sha256"],
                    ["meta_sha256"]=receipt["meta_sha256"]};
                // External context reads can synchronously revoke this operation.
                // Check the generation and switches AFTER every such callback.
                Func<bool> authorized=()=>project()==expectedProject&&context()==expectedContext&&enabled&&compileEnabled&&epoch==generation;
                Need(JToken.DeepEquals(store.Capture(target),expected)&&authorized(),"import_context_changed");
                data=Receipt(receipt);AttachRecovery(data);Remember(data);data["import_attempted"]=true;
                import(data,authorized);
                bool same=JToken.DeepEquals(store.Capture(target),expected);
                data["source_revalidated"]=same;data["grant_active"]=false;
                Need(same&&authorized(),"import_context_changed");
                data["import_returned"]=true;return Ok(data);
            }
            catch(Exception ex){return Fail(ex is CandidateWriteDenied?ex.Message:"import_state_unconfirmed",data);}
            finally{try{if(data!=null)Remember(data);}finally{busy=false;}}
        }
        internal JObject Withdraw(string id)
        {
            if(busy)return Fail("execution_in_progress");busy=true;
            // Local UI only. Revocation does not imply permission for rollback.
            StopAll("本地明确撤回；原任务不恢复");long epoch=generation;
            try
            {
                string expectedProject=project(),expectedContext=context();
                Need(enabled&&compileEnabled&&Digest(expectedContext),"local_recovery_effect_consent_required");
                Need(diagnostics.ContainsKey(id)||diagnostics.Count<128,"diagnostic_capacity");
                var previous=store.LocalTransaction(id);CheckDiagnosticIdentity(previous);ReserveDiagnostics((string)previous["target"]);
                var receipt=store.Restore(id,()=>project()==expectedProject&&context()==expectedContext&&epoch==generation&&enabled&&compileEnabled);
                var data=Receipt(receipt);AttachRecovery(data);Remember(data);
                return (string)receipt["outcome"]=="restored"&&receipt["error"]?.Type==JTokenType.Null?Ok(data):Fail("recovery_preserved",data);
            }
            catch(Exception ex){return Fail(ex is CandidateWriteDenied?ex.Message:"recovery_state_unconfirmed");}
            finally{busy=false;}
        }
        static JObject Receipt(JObject receipt)=>new JObject{["transaction"]=receipt.DeepClone(),["scene_saved"]=false,
            ["compilation_verified"]=false,["automatic_import_possible"]=true,["callback_effects_path_bounded"]=false,
            ["all_mutations_observed"]=false};
        internal JObject Dispatch(JObject input)
        {
            bool stop=(string)input?["kind"]=="stop";if(busy&&!stop)return Fail("execution_in_progress");
            bool previousBusy=busy;busy=true;string client=null;Plan executing=null;
            try
            {
                Need(input!=null&&System.Text.Encoding.UTF8.GetByteCount(input.ToString(Formatting.None))<=1024*1024,"request_budget");
                var r=(JObject)input.DeepClone();Keys(r,"protocol","kind","project_id","connection_id","client_id","task_id","plan_id","body");
                Need(r["protocol"]?.Type==JTokenType.Integer&&(long)r["protocol"]==1,"unsupported_protocol");
                Need(Text(r["project_id"])==project()&&Text(r["connection_id"])==connection(),"binding_changed");
                client=Text(r["client_id"]);string task=Text(r["task_id"]),kind=Text(r["kind"]);var body=r["body"] as JObject;
                if(kind=="prepare")
                {
                    Observe();Need(plan==null||plan.Client==client,"project_write_busy");StopAll("新清单替代旧授权");
                    Keys(body,"target","ttl_seconds","effects");Need(r["plan_id"]?.Type==JTokenType.String&&(string)r["plan_id"]=="","unexpected_identity");
                    Need(enabled&&compileEnabled,"capability_disabled");string target=ScriptFileStore.Target(Text(body["target"]));ReserveDiagnostics(target);
                    Need(JToken.DeepEquals(body["effects"],new JArray("source_import_compile_callbacks")),"explicit_compile_effect_required");
                    Need(body["ttl_seconds"]?.Type==JTokenType.Float||body["ttl_seconds"]?.Type==JTokenType.Integer,"invalid_ttl");
                    double ttl=(double)body["ttl_seconds"],now=Now();Need(!double.IsNaN(ttl)&&!double.IsInfinity(ttl)&&ttl>0&&ttl<=900&&now+ttl>now,"invalid_ttl");
                    Need(history.Count<128,"history_capacity");
                    long epoch=generation;string plugin=context();Need(Digest(plugin),"local_plugin_trust_required");
                    var p=new Plan{Id=Guid.NewGuid().ToString("N"),Client=client,Task=task,Project=project(),Connection=connection(),Target=target,
                        Context=plugin,Expires=now+ttl,Manifest=body,Evidence=store.Capture(target)};
                    Need(plugin==context()&&p.Project==project()&&p.Connection==connection()&&Now()<p.Expires&&epoch==generation&&enabled&&compileEnabled,"prepare_cancelled");
                    p.Digest=ProjectPluginTrust.Digest(new JObject{["id"]=p.Id,["project"]=p.Project,["connection"]=p.Connection,["client"]=client,
                        ["task"]=task,["expires_at"]=p.Expires,["manifest"]=body.DeepClone(),["context"]=plugin,["evidence"]=p.Evidence.DeepClone()}.ToString(Formatting.None));
                    plan=p;history[p.Id]=p;return Ok(new JObject{["status"]="pending",["plan_id"]=p.Id,["digest"]=p.Digest});
                }
                if(kind=="status"){Keys(body);Need(r["plan_id"]?.Type==JTokenType.String,"invalid_string");return Status(client,task,(string)r["plan_id"]);}
                if(kind=="stop")
                {
                    Keys(body);string id=Text(r["plan_id"]);
                    Need(history.TryGetValue(id,out var stopped)&&stopped.Client==client&&stopped.Task==task&&
                        stopped.Project==project()&&stopped.Connection==connection(),"plan_not_current");
                    Need(plan==null||ReferenceEquals(plan,stopped),"plan_not_current");
                    bool already=!ReferenceEquals(plan,stopped);
                    if(!already)StopAll("任务停止；保留直接修改和备份");
                    return Ok(new JObject{["status"]="stopped",["already_stopped"]=already,["grant_active"]=false});
                }
                var active=plan;Need(active!=null&&active.Client==client&&active.Task==task&&Text(r["plan_id"])==active.Id,"plan_not_current");
                executing=active;
                Need(kind=="execute","unknown_kind");Keys(body,"content");Need(body["content"]?.Type==JTokenType.String,"invalid_source_text");
                Current(active,true);Verify(active);Current(active,true);Need(diagnostics.Count<128,"diagnostic_capacity");ReserveDiagnostics(active.Target);
                var receipt=store.Write(active.Target,active.Evidence,(string)body["content"],()=>{try{Current(active,true);return true;}catch{return false;}});
                var data=Receipt(receipt);Remember(data);active.LastReceipt=(JObject)data.DeepClone();
                if((string)receipt["outcome"]!="changed"||receipt["error"]?.Type!=JTokenType.Null)
                {StopAll("写入未确认完成；保留现场与备份，不自动回退");return Fail("write_preserved",data);}
                try
                {
                    Current(active,true);var observed=store.Capture(active.Target);Current(active,true);
                    Need((string)observed["sha256"]==(string)receipt["expected_after_sha256"]&&(string)observed["meta_sha256"]==(string)receipt["meta_sha256"],"postimage_conflict");
                    active.Evidence=observed;data["grant_active"]=true;return Ok(data);
                }
                catch{StopAll("写后已撤权或发生并发变化；保留实际回执");data["grant_active"]=false;return Fail("written_but_revalidation_failed",data);}
            }
            catch(Exception ex)
            {
                if(!stop&&executing!=null&&ReferenceEquals(plan,executing))StopAll("调用失败；原件现场与备份保留");
                return Fail(ex is CandidateWriteDenied?ex.Message:"local_validation_failed");
            }
            finally{busy=previousBusy;}
        }
    }
}
