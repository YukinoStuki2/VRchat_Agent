#if UNITY_EDITOR
using System;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.Compilation;
using UnityEngine;

namespace Yukino.VRChatAgent
{
    // Local approval/history adapter. No grant or capability is persisted.
    // Reload retains an inert task hint only. A newly prepared task, fresh local
    // plugin consent and exact-history approval are required; no grant transfer.
    [InitializeOnLoad]
    internal static class ScriptCandidateSession
    {
        static ScriptWriteGate gate;
        // At most 128 transactions, two bounded snapshots each; reserve room
        // for the displayed phase pair and inert task metadata as well.
        const int ObservationBudget=ScriptWriteGate.DiagnosticEnvelopeBytes;
        static JArray history=new JArray();
        static JArray savedDiagnostics=new JArray();
        static string historyError="";
        static JObject taskRecord;
        static bool awaitingContinuation;
        static string compilationTransaction;
        static JObject compilationData;
        static bool compilationSeen;
        static int compilationErrors;
        static string ReceiptKey=>"Yukino.VRChatAgent.script-observation.v1."+CoplayProjectIdentity.GetProjectHash();
        internal static JObject LastReceipt {get;private set;}
        internal static ScriptWriteGate Gate
        {
            get
            {
                if(gate==null && Environment.OSVersion.Platform==PlatformID.Win32NT)
                    gate=CreateGate(new ScriptFileStore(Directory.GetParent(Application.dataPath).FullName));
                return gate;
            }
        }
        internal static ScriptWriteGate CreateGate(ScriptFileStore store)
        {
            var created=new ScriptWriteGate(()=>EditorApplication.timeSinceStartup,CoplayProjectIdentity.GetProjectHash,CandidateSession.LiveConnection,
                ()=>CandidateSession.Plugins.Evidence("source_import_compile_callbacks","ScriptSource"),store);
            created.LoadDiagnostics(savedDiagnostics);return created;
        }
        static ScriptCandidateSession()
        {
            LoadObservation();
            EditorApplication.update+=()=>gate?.Observe();
            CompilationPipeline.compilationStarted+=_=>
            {
                if(compilationTransaction==null)return;
                compilationSeen=true;compilationErrors=0;PublishCompilation("compiling");
            };
            CompilationPipeline.assemblyCompilationFinished+=(path,messages)=>
            {
                if(!compilationSeen||messages==null)return;
                foreach(var message in messages)if(message.type==CompilerMessageType.Error&&compilationErrors<100000)compilationErrors++;
            };
            CompilationPipeline.compilationFinished+=_=>
            {
                if(!compilationSeen)return;
                compilationSeen=false;PublishCompilation(compilationErrors>0?"failed_preserved":"compile_finished_reload_unverified");
                compilationTransaction=null; // A later, unrelated compile cannot rewrite this receipt.
            };
            AssemblyReloadEvents.beforeAssemblyReload+=()=>{SaveObservation();Stop("重载已撤销单文件授权；持久备份保留");};
            EditorApplication.quitting+=()=>{SessionState.EraseString(ReceiptKey);Stop("退出已撤销单文件授权；不回退文件");};
            EditorApplication.playModeStateChanged+=_=>Stop("播放状态变化已撤销单文件授权");
        }
        static void SaveObservation()
        {
            // SessionState is historical display only, never an approval source.
            try
            {
                if(gate!=null)savedDiagnostics=gate.ExportDiagnostics();
                if(LastReceipt?["data"]?["transaction"]==null&&taskRecord==null&&savedDiagnostics.Count==0)
                {SessionState.EraseString(ReceiptKey);return;}
                string raw=new JObject{["project"]=CoplayProjectIdentity.GetProjectHash(),
                    ["receipt"]=LastReceipt==null?JValue.CreateNull():(JToken)LastReceipt.DeepClone(),
                    ["task_record"]=taskRecord==null?JValue.CreateNull():(JToken)taskRecord.DeepClone(),
                    ["diagnostics"]=savedDiagnostics.DeepClone()}.ToString(Formatting.None);
                if(System.Text.Encoding.UTF8.GetByteCount(raw)>ObservationBudget)throw new InvalidDataException();
                SessionState.SetString(ReceiptKey,raw);
            }
            catch{historyError="重载前最新回执保存未确认；保留上一份已保存历史及持久文件备份";}
        }
        static void LoadObservation()
        {
            string raw=SessionState.GetString(ReceiptKey,"");SessionState.EraseString(ReceiptKey);
            if(raw.Length==0)return;
            try
            {
                if(System.Text.Encoding.UTF8.GetByteCount(raw)>ObservationBudget)throw new InvalidDataException();
                JObject row;
                using(var text=new StringReader(raw))using(var reader=new JsonTextReader(text){MaxDepth=10})
                {row=JObject.Load(reader,new JsonLoadSettings{DuplicatePropertyNameHandling=DuplicatePropertyNameHandling.Error});if(reader.Read())throw new InvalidDataException();}
                if(row.Count<2||row.Count>4||(string)row["project"]!=CoplayProjectIdentity.GetProjectHash()||
                    row["receipt"]==null||(row.Count>=3&&row["task_record"]==null)||
                    (row.Count==4&&!(row["diagnostics"] is JArray)))throw new InvalidDataException();
                savedDiagnostics=row["diagnostics"] as JArray??new JArray();
                // Validate inert data without creating a file store or restoring grants.
                new ScriptWriteGate(null,null,null,null,null).LoadDiagnostics(savedDiagnostics);
                var record=row["task_record"] as JObject;
                if(record!=null)
                {
                    if(record.Count!=5||!(record["manifest"] is JObject manifest)||manifest.Count!=3||
                        manifest["target"]?.Type!=JTokenType.String||
                        !JToken.DeepEquals(manifest["effects"],new JArray("source_import_compile_callbacks"))||
                        !(ReloadTransfer.Number(manifest["ttl_seconds"])>0&&ReloadTransfer.Number(manifest["ttl_seconds"])<=900))throw new InvalidDataException();
                    ScriptFileStore.Target((string)manifest["target"]);
                    foreach(string key in new[]{"task_id","client_id","plan_id","transaction_id"})
                    {var value=record[key];if(value?.Type!=JTokenType.String||string.IsNullOrWhiteSpace((string)value)||((string)value).Length>512||((string)value).Trim()!=(string)value||System.Linq.Enumerable.Any((string)value,char.IsControl))throw new InvalidDataException();}
                    if(!Guid.TryParseExact((string)record["transaction_id"],"N",out _))throw new InvalidDataException();
                }
                if(row["receipt"] is JObject receipt && receipt["data"] is JObject data && data["transaction"] is JObject transaction)
                {
                    if(!Guid.TryParseExact((string)transaction["transaction_id"],"N",out _))throw new InvalidDataException();
                    ScriptFileStore.Target((string)transaction["target"]);
                    data["reload_observed"]=true;data["grant_active"]=false;data["compilation_verified"]=false;
                    data["source_revalidated"]=false;data["receipt_is_historical"]=true;LastReceipt=receipt;
                }
                else if(record==null)throw new InvalidDataException();
                taskRecord=record;awaitingContinuation=record!=null;
            }
            catch{LastReceipt=null;taskRecord=null;savedDiagnostics=new JArray();awaitingContinuation=false;historyError="重载历史无效；未恢复权限或修改文件";}
        }
        static void BeginCompilation(JObject data)
        {
            string target=(string)data?["transaction"]?["target"];
            compilationTransaction=target!=null&&target.EndsWith(".cs",StringComparison.Ordinal)?(string)data["transaction"]["transaction_id"]:null;
            compilationData=data;compilationSeen=false;compilationErrors=0;
        }
        static void PublishCompilation(string state)
        {
            var observation=ScriptWriteGate.CompilationObservation(compilationData?["transaction"] as JObject,state,compilationErrors);
            gate?.ObserveCompilation(compilationTransaction,observation);
            if((string)compilationData?["transaction"]?["transaction_id"]==compilationTransaction)
                ScriptWriteGate.ApplyCompilation(compilationData,observation);
            // A denied local action may display a historical copy of this phase.
            // Keep its observation current without replacing the denial envelope.
            if(LastReceipt?["data"] is JObject visible)
                ScriptWriteGate.ApplyCompilation(visible,observation);
        }
        internal static bool HasPlans=>gate!=null&&gate.LocalPlans().Count>0;
        internal static void Stop(string reason)=>gate?.StopAll(reason);
        static void RefreshHistory()
        {
            try{history=Gate?.LocalHistory()??new JArray();historyError="";}
            catch{history=new JArray();historyError="历史读取未确认；未执行恢复，备份不删除";}
        }
        internal static JObject Dispatch(JObject request)
        {
            var active=Gate;
            if(active==null)return new JObject{["success"]=false,["error"]="windows_file_contract_required",["data"]=new JObject{["status"]="denied"}};
            string kind=(string)request?["kind"];
            if((kind=="prepare"||kind=="execute")&&(EditorApplication.isCompiling||EditorApplication.isUpdating||CandidateReload.Pending))
                return new JObject{["success"]=false,["error"]="editor_not_ready",["data"]=new JObject{["status"]="denied"}};
            // Capture only the authenticated gate's exact plan, never infer a task
            // from SessionState. This metadata itself cannot authorize execution.
            JObject writingPlan=null;
            if(kind=="execute")foreach(JObject row in active.LocalPlans())
                if((string)row["plan_id"]==(string)request["plan_id"])writingPlan=row;
            var result=active.Dispatch(request);
            if((string)request?["kind"]=="execute")
            {
                // Local history must not be copied into a rejected remote response.
                ShowReceipt((JObject)result.DeepClone(),"execute");RefreshHistory();
                if((bool?)result["success"]==true)
                {
                    if(writingPlan!=null)
                        taskRecord=new JObject{["task_id"]=writingPlan["task_id"],["client_id"]=writingPlan["client_id"],
                            ["plan_id"]=writingPlan["plan_id"],["manifest"]=writingPlan["manifest"].DeepClone(),
                            ["transaction_id"]=result["data"]["transaction"]["transaction_id"]};
                    BeginCompilation(LastReceipt["data"] as JObject);
                }
            }
            return result;
        }
        static bool EditorReady=>!EditorApplication.isCompiling&&!EditorApplication.isUpdating&&!EditorApplication.isPlayingOrWillChangePlaymode&&!CandidateReload.Pending;
        static JObject ShowReceipt(JObject result,string operation)
        {
            // No transaction means no new phase: preserve the previous observation,
            // including in-flight callbacks, without hiding the actual refusal.
            if(result?["data"]?["transaction"]==null && LastReceipt?["data"] is JObject previous)
            {
                result["data"]=previous.DeepClone();result["data"]["receipt_is_historical"]=true;
                result["denied_operation"]=operation;
            }
            LastReceipt=result;return result;
        }
        internal static JObject ImportLocal(string id)
        {
            if(!EditorReady)
                return ShowReceipt(new JObject{["success"]=false,["error"]="editor_not_ready"},"import");
            var result=CandidateSession.WithWriteLease(true,()=>Gate.ImportLocal(id,(data,authorized)=>
            {
                if(!authorized())throw new CandidateWriteDenied("import_revoked");
                string target=(string)data["transaction"]["target"];
                BeginCompilation(data);
                data["import_requested"]=true;
                AssetDatabase.ImportAsset(target,ImportAssetOptions.ForceSynchronousImport);
                data["import_returned"]=true;
                if((string)data["compilation"]?["state"]=="failed_preserved")throw new CandidateWriteDenied("script_compilation_failed");
                if(target.EndsWith(".shader",StringComparison.Ordinal))
                {
                    if(!authorized())throw new CandidateWriteDenied("import_revoked");
                    var shader=AssetDatabase.LoadAssetAtPath<Shader>(target);
                    if(shader==null)throw new CandidateWriteDenied("shader_load_unconfirmed");
                    if(!authorized())throw new CandidateWriteDenied("import_revoked");
                    var messages=ShaderUtil.GetShaderMessages(shader);
                    if(messages==null)throw new CandidateWriteDenied("shader_diagnostics_unconfirmed");
                    int errors=0;foreach(var message in messages)if(message.severity==UnityEditor.Rendering.ShaderCompilerMessageSeverity.Error&&errors<100000)errors++;
                    var observation=ScriptWriteGate.CompilationObservation(data["transaction"] as JObject,
                        errors>0?"shader_errors_preserved":"shader_import_no_reported_errors",errors);
                    ScriptWriteGate.ApplyCompilation(data,observation);
                    gate?.ObserveCompilation(id,observation);
                    data["import_returned"]=true;
                    if(errors>0)throw new CandidateWriteDenied("shader_compilation_failed");
                }
            }));
            ShowReceipt(result,"import");RefreshHistory();return result;
        }
        internal static void Draw()
        {
            EditorGUILayout.Space();EditorGUILayout.LabelField("单个既有C#/Shader文件修改","本地批准、持久备份与明确恢复");
            EditorGUILayout.HelpBox("仅单个既有Assets源文件；不创建文件、不保存场景。源改动可能触发导入、编译及受信插件回调，并非插件沙箱。写入回读不代表编译成功；重载后的历史不是权限。停止不回退，恢复必须核对精确postimage。",MessageType.Warning);
            var active=Gate;
            if(active==null){EditorGUILayout.LabelField("单文件写入不可用","需要已验证的Windows本地固定盘文件合同");return;}
            bool enabled=EditorGUILayout.ToggleLeft("允许单个既有C#/Shader文件修改",active.Enabled);
            if(enabled!=active.Enabled){CandidateReload.Cancel();active.SetCapability(enabled);}
            bool compile=EditorGUILayout.ToggleLeft("允许本任务源文件导入/编译回调",active.CompileEnabled);
            if(compile!=active.CompileEnabled){CandidateReload.Cancel();active.SetCompileCapability(compile);}
            EditorGUILayout.LabelField("单文件状态",active.LastReason);
            if(awaitingContinuation&&taskRecord!=null)
            {
                EditorGUILayout.LabelField("待本地重新批准的单文件任务",taskRecord.ToString());
                EditorGUILayout.HelpBox("重载只保留历史，不恢复旧授权。重新连接并认可当前工程插件后，由客户端重新提交同任务同文件清单；核验持久记录及当前文件后再批准。当前客户端与旧身份分别展示，不自动继承。",MessageType.Warning);
            }
            foreach(JObject plan in active.LocalPlans())
            {
                EditorGUILayout.LabelField("单文件任务 / 客户端",(string)plan["task_id"]+" / "+(string)plan["client_id"]);
                EditorGUILayout.LabelField("单文件完整清单",plan["manifest"].ToString());
                EditorGUILayout.LabelField("单文件清单摘要",(string)plan["digest"]);
                EditorGUILayout.LabelField("批准前源文件证据",plan["evidence"].ToString());
                EditorGUI.BeginDisabledGroup((bool)plan["approved"]);
                bool continuation=awaitingContinuation&&taskRecord!=null&&(string)plan["task_id"]==(string)taskRecord["task_id"];
                if(GUILayout.Button(continuation?"核验历史并批准续接任务":"批准此单文件任务"))
                {
                    if(continuation)
                    {
                        bool sameTarget=(string)plan["manifest"]["target"]==(string)taskRecord["manifest"]["target"];
                        if(sameTarget&&active.ApproveContinuation((string)plan["plan_id"],(string)plan["digest"],(string)taskRecord["transaction_id"]))
                            awaitingContinuation=false;
                        else historyError="续接核验未通过；未恢复权限，保留文件与备份";
                    }
                    else active.Approve((string)plan["plan_id"],(string)plan["digest"]);
                }
                EditorGUI.EndDisabledGroup();
            }
            if(LastReceipt!=null)EditorGUILayout.LabelField("单文件最近真实回执",LastReceipt.ToString());
            if(GUILayout.Button("读取单文件持久历史（不恢复权限）"))RefreshHistory();
            if(historyError!="")EditorGUILayout.HelpBox(historyError,MessageType.Warning);
            foreach(JObject row in history)
            {
                EditorGUILayout.LabelField("单文件持久修改记录",row.ToString());
                string state=(string)row["outcome"];
                EditorGUI.BeginDisabledGroup(state!="changed"&&state!="restored");
                if(GUILayout.Button("导入并核验此单文件修改 "+(string)row["transaction_id"]))ImportLocal((string)row["transaction_id"]);
                EditorGUI.EndDisabledGroup();
                EditorGUI.BeginDisabledGroup(state!="prepared"&&state!="changed"&&state!="unknown");
                if(GUILayout.Button("明确恢复此单文件修改 "+(string)row["transaction_id"]))
                {
                    var result=EditorReady?CandidateSession.WithWriteLease(true,()=>active.Withdraw((string)row["transaction_id"])):
                        new JObject{["success"]=false,["error"]="editor_not_ready"};
                    ShowReceipt(result,"restore");
                    if((bool?)result["success"]==true)BeginCompilation(result["data"] as JObject);
                    RefreshHistory();
                }
                EditorGUI.EndDisabledGroup();
            }
        }
    }
}
#endif
