#if UNITY_EDITOR
using System;
using System.IO;
using Newtonsoft.Json.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace Yukino.VRChatAgent
{
    [InitializeOnLoad]
    internal static class VisualCaptureSession
    {
        static readonly string outputFolder="UserSettings/VRChatAgentVisual/"+Guid.NewGuid().ToString("N");
        static string LedgerKey=>"Yukino.VRChatAgent.visual-used.v1."+CoplayProjectIdentity.GetProjectHash();
        internal static readonly VisualCaptureGate Gate=new VisualCaptureGate(
            ()=>EditorApplication.timeSinceStartup,CoplayProjectIdentity.GetProjectHash,CandidateSession.LiveConnection,
            Context,Capture,()=>SessionState.GetString(LedgerKey,""),value=>SessionState.SetString(LedgerKey,value));
        static Texture2D preview;
        static string previewAttempt,previewDigest;
        static bool painted;
        static VisualCaptureSession()
        {
            EditorApplication.update+=Gate.Observe;
            AssemblyReloadEvents.beforeAssemblyReload+=()=>Stop("重载停止视觉任务；次数不重置");
            EditorApplication.playModeStateChanged+=_=>Stop("播放状态变化；视觉任务停止");
            EditorApplication.quitting+=()=>{Stop("退出；不外发未确认图片");SessionState.EraseString(LedgerKey);};
        }
        internal static void Stop(string reason){Gate.StopAll(reason);ReleasePreview();}
        static void ReleasePreview()
        {
            if(preview!=null)UnityEngine.Object.DestroyImmediate(preview);
            preview=null;previewAttempt=null;previewDigest=null;painted=false;
        }
        static void Need(bool condition){if(!condition)throw new InvalidOperationException("visual_context_or_capture_invalid");}
        static string Root=>Directory.GetParent(Application.dataPath).FullName;
        // Pinned producer returns forward slashes on Windows too. Transform
        // only our expected local path; never repair an untrusted result token.
        internal static bool MatchesNativePath(string expected,string returned)=>returned==expected.Replace('\\','/');
        static string CheckedPath(string relative)
        {
            // Owner-generated path, never a model field. The locally trusted
            // project/plugins are not an OS sandbox; reject observed links.
            Need(relative.StartsWith(outputFolder,StringComparison.Ordinal));
            string full=Path.GetFullPath(Path.Combine(Root,relative));
            Need(full.StartsWith(Path.GetFullPath(Root)+Path.DirectorySeparatorChar,StringComparison.Ordinal));
            for(string path=full;path!=null;path=Path.GetDirectoryName(path))
                if(File.Exists(path)||Directory.Exists(path))Need((File.GetAttributes(path)&FileAttributes.ReparsePoint)==0);
            return full;
        }
        static JObject Context()
        {
            Need(!Application.isBatchMode && !EditorApplication.isCompiling && !EditorApplication.isUpdating && !EditorApplication.isPlayingOrWillChangePlaymode);
            var view=SceneView.lastActiveSceneView;Need(view!=null);
            string trust=CandidateSession.Plugins.Evidence("visual_capture_callbacks","SceneView");Need(trust!=null);
            double width=view.position.width*EditorGUIUtility.pixelsPerPoint,height=view.position.height*EditorGUIUtility.pixelsPerPoint;
            Need(width>0 && height>0 && width<=2048 && height<=2048);
            CheckedPath(outputFolder);
            var scene=EditorSceneManager.GetActiveScene();var stage=PrefabStageUtility.GetCurrentPrefabStage();
            Need(scene.IsValid());
            return new JObject{["view_id"]=view.GetInstanceID(),["scene_handle"]=scene.handle,["scene_path"]=scene.path,
                ["prefab_stage"]=stage?.assetPath??"",["prefab_scene_handle"]=stage?.scene.handle??0,
                ["viewport_bound_width"]=width,["viewport_bound_height"]=height,["output_folder"]=outputFolder,["plugin_trust"]=trust};
        }
        static JObject Capture(JObject scope,int attempt)
        {
            Need(JToken.DeepEquals(scope,Context()));
            string name="capture-"+Guid.NewGuid().ToString("N")+".png",relative=outputFolder+"/"+name;
            string full=CheckedPath(relative);Need(!File.Exists(full) && !Directory.Exists(full));
            // Exact pinned original implementation; no registry override, camera
            // creation, auto framing, batch, Play Mode, Refresh or Assets import.
            object raw=MCPForUnity.Editor.Tools.Cameras.ManageCamera.HandleCommand(new JObject{
                ["action"]="screenshot",["captureSource"]="scene_view",["includeImage"]=true,
                ["maxResolution"]=640,["superSize"]=1,["fileName"]=name,["outputFolder"]=outputFolder});
            var result=raw as JObject??JObject.FromObject(raw);var data=result["data"] as JObject;
            Need((bool?)result["success"]==true && data!=null && JToken.DeepEquals(scope,Context()));
            Need(data["isAsync"]?.Type==JTokenType.Boolean && (bool)data["isAsync"]==false &&
                (string)data["captureSource"]=="scene_view" && (string)data["captureMode"]=="scene_view_viewport" &&
                (string)data["path"]==relative && MatchesNativePath(full,(string)data["fullPath"]) &&
                data["superSize"]?.Type==JTokenType.Integer && (int)data["superSize"]==1);
            foreach(string dimension in new[]{"viewportWidth","viewportHeight","imageWidth","imageHeight"})Need(data[dimension]?.Type==JTokenType.Integer);
            Need((int)data["viewportWidth"]>0 && (int)data["viewportHeight"]>0 &&
                (int)data["viewportWidth"]<=(double)scope["viewport_bound_width"] && (int)data["viewportHeight"]<=(double)scope["viewport_bound_height"] &&
                (int)data["imageWidth"]>0 && (int)data["imageWidth"]<=640 && (int)data["imageHeight"]>0 && (int)data["imageHeight"]<=640);
            CheckedPath(relative);var file=new FileInfo(full);Need(file.Exists && file.Length>0 && file.Length<=32*1024*1024);
            Need(data["imageBase64"]?.Type==JTokenType.String && ((string)data["imageBase64"]).Length<=700000);
            var image=new JObject{["imageBase64"]=data["imageBase64"].DeepClone(),["imageWidth"]=data["imageWidth"].DeepClone(),["imageHeight"]=data["imageHeight"].DeepClone()};
            byte[] bytes=VisualCaptureGate.Image(image,out int imageWidth,out int imageHeight);
            var decoded=new Texture2D(2,2);
            try{Need(ImageConversion.LoadImage(decoded,bytes,false) && decoded.width==imageWidth && decoded.height==imageHeight);}
            finally{UnityEngine.Object.DestroyImmediate(decoded);}
            // Strip native messages/full paths and every other field. Bytes stay
            // in the final Editor gate until the exact preview is locally accepted.
            return image;
        }
        internal static void Draw()
        {
            EditorGUILayout.Space();EditorGUILayout.LabelField("有界视觉采集",Gate.LastReason);
            EditorGUILayout.HelpBox("只截已打开并手动摆好视角的Scene View。会聚焦/重绘及排队编辑器更新，可能触发受信插件回调；画面不是头像隔离。最多一次标准＋一次非故障修正；每张图都须先在这里预览并确认后才外发给当前主模型。错误即停；不自动删除PNG。",MessageType.Warning);
            EditorGUILayout.LabelField("PNG保留目录（工程内，Assets外）",outputFolder);
            bool next=EditorGUILayout.ToggleLeft("允许Scene View截图（逐张本地确认后外发）",Gate.Allowed);
            if(next!=Gate.Allowed){CandidateReload.Cancel();Gate.SetCapability(next);if(!next)ReleasePreview();}
            foreach(JObject p in Gate.LocalPlans())
            {
                EditorGUILayout.LabelField("视觉任务 / 客户端",(string)p["task_id"]+" / "+(string)p["client_id"]);
                EditorGUILayout.LabelField("视觉清单",p["context"].ToString());
                EditorGUI.BeginDisabledGroup((bool)p["approved"]);
                if(GUILayout.Button("批准此视觉任务（不批准图片外发）"))Gate.ApproveLocal((string)p["plan_id"],(string)p["digest"]);
                EditorGUI.EndDisabledGroup();
            }
            var image=Gate.PreviewLocal();
            if(image==null){ReleasePreview();return;}
            try
            {
                if(previewAttempt!=(string)image["attempt_id"] || previewDigest!=(string)image["sha256"])
                {
                    ReleasePreview();preview=new Texture2D(2,2);
                    Need(ImageConversion.LoadImage(preview,Convert.FromBase64String((string)image["imageBase64"]),false));
                    Need(preview.width==(int)image["imageWidth"] && preview.height==(int)image["imageHeight"]);
                    previewAttempt=(string)image["attempt_id"];previewDigest=(string)image["sha256"];
                }
                Rect rect=GUILayoutUtility.GetRect(640,Math.Max(64,640f*preview.height/preview.width));
                GUI.DrawTexture(rect,preview,ScaleMode.ScaleToFit,false);
                if(Event.current!=null && Event.current.type==EventType.Repaint)painted=true;
                EditorGUILayout.LabelField("本张图片SHA-256",previewDigest);
                EditorGUI.BeginDisabledGroup(!painted);
                if(GUILayout.Button("确认发送此张图片给当前主模型"))Gate.ConfirmImageLocal(previewAttempt,previewDigest);
                EditorGUI.EndDisabledGroup();
                if(GUILayout.Button("拒绝此图并停止视觉任务"))Stop("本地拒绝；未发送图不外发，PNG保留");
            }
            catch{Stop("预览不可核验；停止，不外发");}
        }
    }
}
#endif
