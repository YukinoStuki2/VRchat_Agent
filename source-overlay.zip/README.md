# Hermes 优先预览：ALCOM 安装与验收

本源与旧版 VPM 源独立，包名为 `com.yukino.vrchat-agent`，版本 `0.2.0-preview.1`。不是旧的 Connection Manager。这是供隔离工程验收的预览包，不是稳定发行；主审非独审，Windows 专项暂缓，真实 Unity/模型尚未验收。

## 添加预览源

在 ALCOM 的软件包仓库页面选择添加仓库，粘贴：

`https://github.com/YukinoStuki2/VRchat_Agent/releases/download/hermes-preview-0.2.0-preview.1/index.json`

确认仓库名 **Yukino VRChat Agent — Hermes 优先预览**。开启“显示预发行软件包”，然后进入独立测试工程的管理页面，选择 **Yukino VRChat Agent（Hermes 优先预览）**，版本 **0.2.0-preview.1**。

## 首次安装顺序

1. 使用独立 Windows x64 测试工程或自己已备份的副本；不要直接在现用 Avatar 工程尝试。保留项目当前受支持的 Unity/VRChat SDK，不为安装本包升级整套工程。本包声明 Unity 2022.3。
2. 在 Unity Package Manager 中先安装官方固定 Coplay 包：`https://github.com/CoplayDev/unity-mcp.git?path=/MCPForUnity#v10.2.0`。已有匹配版本不重复安装；其他版本先停止核对，不能盲目覆盖。
3. 当前候选还依赖 Unity Newtonsoft JSON **3.0.2** 和 Unity Test Framework **1.1.31**。若工程版本冲突，先停止并记录，不擅自升级/降级已有依赖。ALCOM 的包文件安装通过不等于 Unity 已解析这些 UPM 依赖。
4. Windows 应具备微软官方 Visual C++ v14 **x64** 运行库：`https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist`。缺失时由本人从微软安装；本包不附带 DLL，也不自动安装系统组件。
5. 关闭 Unity。在 ALCOM 添加上述源、启用预发行显示、安装本包。不要同时安装旧 `com.yukino.vrchat-readonly-mcp`、`com.yukino.vrchat-managed-editing`、`com.yukino.vrchat-agent-launcher` 来混用两条接入路径。本候选不会删除它们；建议用无这些旧包的新工程测试。
6. 重新打开 Unity，先只检查导入/Console 与权限窗口默认关闭。不启用任意写入；编译错误保留原文，不清 Console，不自动回退或删除模型。

## 验收范围

- 本包安装、更新和打开窗口不会自动启动连接或批准任务。四类实时读取、单文件修改及每张图片预览均仍受本地开关/插件信任/任务批准约束。
- 真实 Unity 的编译、域重载、界面、撤回，以及 Windows ALCOM 点击操作，须由操作者实际验收。Linux 上的 vrc-get 分发检查不是这些结果。
- Hermes 插件另见同一 Release 的 `vrchat-agent-hermes-0.2.0-preview.1.zip`，不由 ALCOM 安装到服务器。插件按内含 INSTALL.md 正常扫描安装，保持默认关闭。本次分发不会更改现用 Hermes。
- 当前图片出口只支持 Linux pidfd＋HTTPS Chat＋静态内存 Bearer＋已识别原生直连 HTTPX；代理、凭据池、Responses/Codex OAuth 等拒绝，不会静默换路。真实模型调用另行确认。
- 功能是包内明确支持的子集，不是上游全部能力。未开放操作会拒绝；不保存场景、不上传 Avatar、不授予任意代码执行。

## 版本、来源与退出

- SHA256SUMS.json 和 index.json 随 Release 提供；同版本文件不覆盖。
- 此 Git 分支仅承载预览分发输入和工作流；当前候选源码在包内 Editor/ 与 Runtime~/ 中。不会用分支自动生成的 Source code ZIP 冒充 Unity 安装包。
- Runtime 字节复用固定 `14aea85f6703e8aa48270c79ead29fa18ce1e0ab` 的已核开发载荷。新增分发工作流不运行 Windows 测试、Unity 或模型。
- 若需要卸载，先本地停止连接、关闭 Unity，再由 ALCOM 移除此候选包。卸载代码不等于恢复已修改资产；备份和精确撤回保持原策略，不自动清除。

---
## Historical source README (preserved)

# VRChat Agent 未发布候选源码

此目录不是可安装成品，不要直接添加到真实Unity工程。完整实现、客户端接线、独立审查、运行时分发及集中验收尚未完成。

目标布局：Editor为候选程序集；OwnedTransport子目录的asmref仅将独立传输类型加入固定Coplay程序集；Runtime~包含受控sidecar源码与SDK修订，不交给Unity importer编译。打开窗口/导入本包不会启动服务或授予任务权限。

固定Coplay来源： https://github.com/CoplayDev/unity-mcp/tree/30d22075093d1d35dfb0091c1c7550e9ad948577 ，包版本10.2.0。这里不自动安装或更新它，不升级Unity/VRChat SDK，不移除旧包或工程文件。

已提供固定便携Python的构建及验真流程，但完整安装包尚未发布；入口不会启动时联网安装依赖；账号、令牌、JWT私钥不写文件。停止/撤权不自动回退用户资产。真实Unity/Mono的导入、窗口和生命周期尚未验收。


## Windows 前置运行库

Windows x64 候选要求预先安装微软官方 **Visual C++ v14 Redistributable（x64，当前受支持版本）**。
下载与安装说明：https://learn.microsoft.com/en-us/cpp/windows/latest-supported-vc-redist
由用户从微软官方页面手动安装；本包不附带安装器，不自动下载、不静默安装，也不修改已有系统运行库。

构建时先校验固定 Python 归档内 `vcruntime140.dll`、`vcruntime140_1.dll` 的原始哈希，
再仅从本次新建的运行时副本排除它们；保留 Python 与第三方依赖许可正文。
最终完整载荷再次拒绝这两种 DLL，避免依赖安装把它们带回。
因此本包不是完全免前置条件的便携发行。系统缺少兼容的 x64 运行库时，Python 启动或探测可能失败；
应先按官方说明安装，再手动重试连接，不会回退到系统 Python 或自行补装 DLL。
这只解决所列 DLL 的随包分发边界，不代表其他依赖许可、真实 Unity 或完整产品已获批准。

## 原生能力目录

客户端调用 `agent_catalog(offset=0, limit=12)` 后使用返回的 `next_offset` 逐页读取；目录来自固定版本的随包源码，运行时核验来源摘要。目录不访问Unity、不创建任务或授予权限。中文名称、原始工具/action与尚未接通的状态均保留，不能把“目录可见”解释为“操作已允许”。

本地面板的“展开原生操作目录”显示同一目录。已接通的只读操作复用真实能力开关；未接通操作保持灰色且拒绝，不提供假开关。当前通用只读覆盖仍不完整。

## 任务重载与重新绑定

同一连接内短暂停顿仍使用“暂停/继续”，保持原计划及到期时间。编译重载、断线或停止后旧授权失效，不自动连接、不自动继续写入。

已经成功复制/修改的材质候选会保留本次Editor会话内的任务记录；记录只包含任务范围和最后核验的证据，不包含凭据、活动授权或可跨重载使用的Undo对象。退出Editor即清除；失败的修改不作为可恢复成功点。

重连后重新启用所需的本地操作开关，让客户端以原任务ID提交同一原件/候选和引用范围的新清单（不要再复制已存在候选）。面板显示历史记录与新的认证主体/会话；点击“核验记录并重新批准此绑定”。系统重新检查候选、原件、依赖、引用和当前连接，任一变化则拒绝，保留现场。旧步骤不会重放；新文件/引用不借旧记录扩大权限。读取任务直接重新提交清单并审批，不继承旧读授权。

记录摘要仅作一致性检查，不是签名或真人身份凭据。重载后的明确撤回不复用已失效的Undo对象；不会为恢复而覆盖用户后改内容。当前自动测试包含内核外的C#门控和Unity API替身、Linux原生客户端，仍需真实Editor验收。

## 单个既有 C#/Shader 文件（候选路径，尚待实机验收）

`script_prepare / script_execute / script_status / script_stop` 只管理一个既有 `Assets/` 下的 `.cs` 或 `.shader`，不创建源码、开放远程批准/恢复/执行，也不保存场景。Unity 本地需认可当前工程插件，分别开启单文件写入与导入/编译效果，再批准精确任务。插件认可不是回调沙箱；源码改动可能触发 Unity 自动导入及插件回调。

每次写入先在非编译目录 `UserSettings/VRChatAgent/ScriptBackups/` 保留原始字节和持久事务。写入回读不等于编译成功。 写入结果日志损坏的警告与恢复结果分开记录；有效恢复结果必须独立匹配不可变准备记录，原损坏文件保留。编译观察区分写入后字节与恢复后字节，标注源码及 `.meta` 摘要并保留原失败；该摘要是预期输入关联，不是编译器对实际输入的证明。面板可对记录中的单文件明确发起导入；C# 编译回执按本次项目编译观察，Shader 诊断不承诺所有变体都已验证。失败/停止/断线/重载不自动回退，备份不自动删除。明确恢复只接受精确 postimage 和未变 `.meta`，不会覆盖用户后改；恢复后导入仍需独立本地点击。

编译重载后只保留任务线索及回执，不恢复旧开关、插件信任或授权。重新连接后，在 Unity 重新认可当前工程插件、开启所需能力，由客户端重新提交同任务ID和同文件的新清单。面板分别显示原任务线索与当前认证客户端；点击“核验历史并批准续接任务”重新核验持久记录、备份、源码和 `.meta`，成功才授予新清单。不会延续旧批准、重放旧写入、自动导入或自动编译；有并发变化则停止并保留现场。该脚本路径不参加读取/材质的一次性自动重载授权交接。

## 本地 Codex 开发入口（未做真实Editor验收）

在权限面板勾选本轮Codex，填写官方原生 `codex.exe` 绝对路径（当前验真版本 `0.159.2`，不接受npm的.cmd包装器）。门控连接成功后才启动独立可见控制台；导入/打开窗口不会启动。关闭控制台会结束本轮连接，若同时启用Hermes也会一起关闭。

客户端采用独立临时CODEX_HOME，不导入现用auth.json/配置；登录由用户在该原生控制台完成。`ephemeral`登录保存、禁用历史持久化/插件及受控MCP目录通过CLI覆盖固定；启动不附带提示，不自动发起模型轮次。关闭后账号不保留，重新启动需单独登录。本轮bearer只通过新进程环境交付且从原生终端的默认子环境排除，不写argv/配置/日志；公开证书可写私有临时目录。原生终端不属于MCP硬隔离，仍必须遵守项目AGENTS.md。自定义CA是附加信任，不宣称独占pin。

停止先撤销Unity任务权限，再结束本轮客户端/Job并清理临时profile，最后结束运行时；缺少客户端清理回执不算成功。进程崩溃时Job负责后代退出，但非秘密配置目录的崩溃后磁盘清理不冒称已保证。此入口仍需Windows原生Codex、Unity UI与用户登录完整验收；开发fixture不代替上述验收。

## 受限核心API元数据（本地测试，待实机验收）

`unity_reflect/get_type|get_member|search`复用固定上游读取/格式化方法，
`Editor/ScopedReflection/`是VRchat_Agent自己的独立命名附加类型，asmref加入固定Coplay程序集。
不覆盖已安装的Coplay文件，不修改全局UnityTypeResolver、Hermes源码或安全扫描器。
变换来源、输入hash、固定类型名单见该目录`PROVENANCE.json`，许可证正文一同保留。

必须本地勾选具体操作并批准`ApiMetadata`。仅查询`unity-engine-core-v1`集合：
Object、Component、GameObject、Transform、Animator、RuntimeAnimatorController、AnimationClip、
Material、Shader、SkinnedMeshRenderer、Vector3、Quaternion、Color，均为UnityEngine命名空间。
`class_name`接受集合成员的精确全名或短名；`member_name`为规范标识符，
`search`须显式`scope=unity`及非空规范`query`。拒绝程序集限定名、泛型语法和额外参数。
不读取对象实时值、不调用getter/方法、不查询项目/插件类型，不进行扩展方法发现。

返回`candidate_scope`明确标识类型集合以及`all_loaded_types=false`、
`extension_methods_included=false`。范围外类型/成员的`found=false`仅指本候选范围内没有结果，
绝不证明该API在整个工程/Unity中不存在；空扩展方法列表也不表示工程没有扩展方法。
原生读取主体保留，但通用上游反射入口仍被候选门控拒绝。
本地.NET回调对照测试和Unity API替身不替代真实Unity/Mono、UI和不同SDK/插件组合验收。

## 三类实时效果读取：默认关闭的候选入口

已接入资产`manage_asset/search,get_info`、Prefab `manage_prefabs/get_info,get_hierarchy`和非缓存测试发现`get_tests`（精确`EditMode`/`PlayMode`）。这不是纯只读或插件沙箱：加载/清理与发现可能触发工程插件回调，无法保证阻止内部未知回调，也不能承诺观察全部作用。

本地顺序为：核对当前工程并两步确认信任其插件 → 单独打开对应效果开关和具体操作能力 → 客户端提交含effects的精确任务清单 → 本地核对并批准。任何一步都不代替其他步骤，MCP没有认可插件/批准任务接口。连接、打开窗口或查看目录均不会自动授予这些权限。

- 资产：目标`AssetReads/Assets/...`；effect为`asset_load_callbacks`版本1。预览必须显式关闭；search明确页码/页大小，返回是实时页面而非快照。禁止刷新/全工程无效目录回退/写分支。
- Prefab：目标`PrefabReads/Assets/*.prefab`；info要求资产effect；hierarchy还需`prefab_contents_callbacks`版本1。仅卸载本次创建的临时内容，不保存或打开Stage。
- 发现：目标`TestDiscovery/EditMode`或`TestDiscovery/PlayMode`；effect为`test_discovery_callbacks`版本1。不启动测试、不维护作业、不抢焦点；有迭代/结果预算和30秒观测期限，但不能强停阻塞中的插件回调。
- 停止先撤销信任及任务，不自动回退作用；观察到连接/包/程序集库存变化要求重新本地核对，库存摘要不是执行代码证明。清理不确定会保留Editor会话拒绝标记，重连/新门控/重新勾选不能擦除它；界面不提供重置绕过。

当前发现附加源码固定于Unity Test Framework 1.1.31，候选显式声明依赖和Editor程序集引用；不宣称已兼容其他版本，也不自动修改真实工程来解决依赖冲突。真实Unity/Mono编译、域重载、UI、平台和VPM安装验收仍是交付前门槛。

### 单文件诊断历史

共享写租约或编辑器忙导致的无效果拒绝保留原编译观察，拒绝原因不会被成功观察覆盖。诊断独立于活计划，以事务、阶段、源码和meta摘要严格关联；同阶段重新导入及重载后恢复保留首次失败。最多128个事务、每个写入/恢复两阶段，容量满时先拒绝新效果，不自动删除备份或恢复权限。重载后仍需新插件信任、重新prepare及本地批准；这些摘要是预期输入关联，并非编译器输入证明。SessionState仅限本次Editor会话，不承诺退出后的编译诊断持久化，磁盘备份保持原策略。
