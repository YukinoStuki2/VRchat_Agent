"""Existing single-file wire contract; local Unity is the final authority.
Reuses the material adapter's authenticated plan lifetime, not its mutation tool.
No remote approve, restore, arbitrary execution or source creation.
"""
from fastmcp import Context
from fastmcp.exceptions import ToolError
from transport.plugin_hub import PluginHub
from material_runtime import MaterialRuntime, asset_path, finite_number, keys, text

TOOLS = {'script_prepare', 'script_execute', 'script_status', 'script_stop'}
ROUTE = 'vrchat_agent_script_dispatch'


def validate(name, args):
    if name == 'script_prepare':
        keys(args, 'task_id', 'target', 'effects', 'ttl_seconds')
        target = asset_path(args['target'])
        if not target.endswith(('.cs', '.shader')):
            raise ToolError('script_extension_required')
        if args['effects'] != ['source_import_compile_callbacks']:
            raise ToolError('explicit_compile_effect_required')
        if not finite_number(args['ttl_seconds']) or not 0 < args['ttl_seconds'] <= 900:
            raise ToolError('invalid_ttl')
    elif name == 'script_execute':
        keys(args, 'task_id', 'plan_id', 'content')
        content = args['content']
        if type(content) is not str or '\0' in content or content.startswith('\ufeff'):
            raise ToolError('invalid_source_text')
        try:
            if len(content.encode('utf-8')) > 131072:
                raise ToolError('source_budget')
        except UnicodeEncodeError:
            raise ToolError('invalid_source_text') from None
    else:
        keys(args, 'task_id', 'plan_id')
    text(args['task_id'])
    if name != 'script_prepare' and not (name == 'script_status' and args['plan_id'] == ''):
        text(args['plan_id'])


class ScriptRuntime(MaterialRuntime):
    prefix = 'script'
    route = ROUTE
    validate = staticmethod(validate)

    @staticmethod
    def execute_body(args):
        return {'content': args['content']}

    async def prepare(self, task_id, target, effects, ttl_seconds):
        return await self.prepare_plan(task_id,
            {'target': target, 'effects': effects, 'ttl_seconds': ttl_seconds}, ttl_seconds)

    async def execute(self, task_id, plan_id, content):
        invocation, plan = self.scope(task_id, plan_id, current=True)
        invocation.plan = plan
        return await PluginHub.send_command(plan.connection_id, 'script_execute', {'content': content})


def register(server, script):
    @server.tool
    async def script_prepare(task_id: str, target: str, effects: list[str], ttl_seconds: float, ctx: Context) -> dict:
        """提交单个既有C#/Shader清单；仅待批，须Unity本地批准文件及编译回调效果。"""
        return await script.prepare(task_id, target, effects, ttl_seconds)

    @server.tool
    async def script_execute(task_id: str, plan_id: str, content: str, ctx: Context) -> dict:
        """仅写已批准的既有文件；保留精确字节备份，写入回读不等于编译成功。"""
        return await script.execute(task_id, plan_id, content)

    @server.tool
    async def script_status(task_id: str, plan_id: str, ctx: Context) -> dict:
        """只查当前会话精确任务的状态回执；不批准、不恢复权限或文件。"""
        return await script.status(task_id, plan_id)

    @server.tool
    async def script_stop(task_id: str, plan_id: str, ctx: Context) -> dict:
        """停止精确单文件任务，保留修改与备份；不自动回退。"""
        return await script.stop(task_id, plan_id)
