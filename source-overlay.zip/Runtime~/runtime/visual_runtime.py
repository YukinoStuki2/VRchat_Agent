"""Bounded visual wire adapter. Unity alone approves each local image preview.
Only confirmed collect replies become MCP ImageContent; no model call here.
"""
import base64
import hashlib
import json
import re
import struct
import time
from dataclasses import dataclass

from fastmcp import Context
from fastmcp.exceptions import ToolError
from fastmcp.tools.tool import ToolResult
from mcp.types import ImageContent, TextContent
from transport.plugin_hub import PluginHub
from candidate_runtime import Invocation, _CURRENT, exact_id, snapshot
from material_runtime import keys, text, finite_number

TOOLS = {'visual_prepare', 'visual_capture', 'visual_collect', 'visual_status', 'visual_stop'}
ROUTE = 'vrchat_agent_visual_dispatch'


def validate(name, args):
    fields = ['task_id']
    if name == 'visual_prepare':
        fields.append('ttl_seconds')
    else:
        fields.append('plan_id')
        if name == 'visual_capture':
            fields.append('correction_reason')
        elif name == 'visual_collect':
            fields.append('attempt_id')
    keys(args, *fields)
    text(args['task_id'])
    if name == 'visual_prepare':
        ttl = args['ttl_seconds']
        if not finite_number(ttl) or not 0 < ttl <= 900:
            raise ToolError('invalid_ttl')
    else:
        text(args['plan_id'])
        if name == 'visual_collect':
            text(args['attempt_id'])
        elif name == 'visual_capture' and args['correction_reason'] != '':
            text(args['correction_reason'])


async def send(connection, command, body):
    try:
        return await PluginHub.send_command(connection, command, body)
    except Exception:
        # Native exception text can contain paths or image data. No retry.
        raise ToolError('visual_operation_failed') from None


def checked_reply(kind, result, plan, body):
    """Reject unknown fields before ANY native data enters TextContent or logs."""
    try:
        if type(result) is not dict or type(result.get('success')) is not bool:
            raise ValueError()
        # The pinned CandidateSession wraps the gate in native Response types.
        # Accept only their observed fixed envelope additions, then discard them
        # before any text/image result. Unknown messages/fields still fail closed.
        result = dict(result)
        if result['success'] and 'message' in result:
            if result.pop('message') != '受控候选操作':
                raise ValueError()
        if not result['success'] and 'code' in result:
            if result.pop('code') != result.get('error'):
                raise ValueError()
        data = result.get('data')
        if not result['success']:
            keys(result, 'success', 'error', 'data')
            keys(data, 'status', 'reason')
            if (data['status'] != 'denied' or data['reason'] != result['error']
                    or type(result['error']) is not str or re.fullmatch(r'[a-z][a-z0-9_]{0,127}', result['error']) is None):
                raise ValueError()
            return result
        keys(result, 'success', 'data')
        if kind == 'prepare':
            keys(data, 'status', 'plan_id', 'digest')
            text(data['plan_id'])
            if data['status'] != 'pending' or type(data['digest']) is not str or re.fullmatch('[0-9a-f]{64}', data['digest']) is None:
                raise ValueError()
        elif kind == 'stop':
            keys(data, 'status')
            if data['status'] != 'stopped':
                raise ValueError()
        else:
            image = kind == 'collect' and type(data) is dict and data.get('status') == 'image_confirmed'
            fields = ['status', 'plan_id', 'attempt_id', 'attempts_used', 'read_only']
            if image:
                fields += ['sha256', 'imageWidth', 'imageHeight', 'imageBase64']
            keys(data, *fields)
            statuses = {'awaiting_local_preview'} if kind == 'capture' else (
                {'awaiting_local_preview', 'image_confirmed'} if kind == 'collect' else
                {'pending', 'ready', 'awaiting_local_preview', 'confirmed', 'sent'})
            if (data['status'] not in statuses or data['plan_id'] != plan.plan_id or data['read_only'] is not False
                    or type(data['attempts_used']) is not int or not 0 <= data['attempts_used'] <= 2):
                raise ValueError()
            if data['attempts_used']:
                text(data['attempt_id'])
            elif kind != 'status' or data['status'] not in {'pending', 'ready'} or data['attempt_id'] != '':
                raise ValueError()
            if kind == 'capture' and data['attempts_used'] != plan.attempts_used + 1:
                raise ValueError()
            if kind == 'collect' and (data['attempt_id'] != body['attempt_id']
                    or data['attempt_id'] != plan.attempt_id or data['attempts_used'] != plan.attempts_used):
                raise ValueError()
            if image:
                encoded = data['imageBase64']
                if type(encoded) is not str or len(encoded) > 700000:
                    raise ValueError()
                raw = base64.b64decode(encoded, validate=True)
                if (not 45 <= len(raw) <= 512 * 1024 or raw[:16] != b'\x89PNG\r\n\x1a\n\0\0\0\rIHDR'
                        or base64.b64encode(raw).decode('ascii') != encoded):
                    raise ValueError()
                width, height = struct.unpack('>II', raw[16:24])
                if (type(data['imageWidth']) is not int or type(data['imageHeight']) is not int
                        or not 0 < width <= 640 or not 0 < height <= 640
                        or (width, height) != (data['imageWidth'], data['imageHeight'])
                        or data['sha256'] != hashlib.sha256(raw).hexdigest()):
                    raise ValueError()
                receipt = {'success': True, 'data': {k: v for k, v in data.items() if k != 'imageBase64'}}
                return ToolResult(content=[TextContent(type='text', text=json.dumps(receipt)),
                    ImageContent(type='image', data=encoded, mimeType='image/png')], structured_content=receipt)
        return result
    except Exception:
        raise ToolError('invalid_visual_reply') from None


@dataclass
class VisualPlan:
    task_id: str
    connection_id: str
    expires_at: float
    plan_id: str = ''
    approval_client: str = ''
    attempts_used: int = 0
    attempt_id: str = ''
    sent: bool = False
    busy: bool = False


class VisualRuntime:
    def __init__(self, runtime):
        self.runtime = runtime
        self.plans = {}
        self.preparing = {}

    def connection_closed(self, connection_id):
        for client, pending in list(self.preparing.items()):
            if pending.plan is not None and pending.plan.connection_id == connection_id:
                pending.cancelled = True
                self.preparing.pop(client)
        for client, plan in list(self.plans.items()):
            if plan.connection_id == connection_id:
                self.plans.pop(client)
                self.runtime.lifecycle_results.append({'client_id': client, 'local_revoked': True,
                    'unity_confirmed': False, 'reason': 'unity_connection_closed', 'command': 'visual_stop',
                    'task_id': plan.task_id, 'plan_id': plan.plan_id, 'connection_id': connection_id})

    def bound(self, invocation, *, preparing=False):
        client, plan = invocation.client_id, invocation.plan
        if (not invocation.active or invocation.cancelled
                or self.runtime.sessions.get(client) is not invocation.visual_session
                or self.runtime.session_identities.get(client) != invocation.approval_client):
            raise ToolError('visual_binding_changed')
        if preparing:
            if self.preparing.get(client) is not invocation:
                raise ToolError('prepare_cancelled')
        elif invocation.name != 'visual_stop' and self.plans.get(client) is not plan:
            raise ToolError('plan_not_current')
        if plan is not None and invocation.name != 'visual_stop' and time.monotonic() >= plan.expires_at:
            raise ToolError('plan_expired')

    async def recheck(self, invocation, *, preparing=False):
        connection = await self.runtime.connection()
        self.bound(invocation, preparing=preparing)
        if invocation.plan is not None and connection != invocation.plan.connection_id:
            raise ToolError('connection_changed')

    async def on_call_tool(self, context, call_next):
        ctx = context.fastmcp_context
        if ctx is None or not ctx.session_id:
            raise ToolError('request_not_bound')
        identity = self.runtime.bind_session(ctx)
        invocation = Invocation(self.runtime, ctx.session_id, context.message.name,
                                snapshot(context.message.arguments or {}), approval_client=identity)
        invocation.visual_session = ctx.session
        token = _CURRENT.set(invocation)
        self.runtime.inflight[id(invocation)] = invocation
        completed = False
        try:
            validate(invocation.name, invocation.arguments)
            await ctx.set_state('unity_instance', self.runtime.project_id)
            result = await call_next(context)
            data = result.structured_content
            if type(data) is not dict or type(data.get('success')) is not bool:
                raise ToolError('invalid_visual_result')
            succeeded = not result.is_error and isinstance(data, dict) and data.get('success') is True
            if succeeded:
                await self.recheck(invocation)
            completed = succeeded
            if isinstance(data, dict) and data.get('success') is False:
                result.is_error = True
            return result
        finally:
            try:
                if not completed and invocation.plan is not None and self.plans.get(invocation.client_id) is invocation.plan:
                    self.plans.pop(invocation.client_id)
                    await self.runtime.notify_stop(invocation.client_id, invocation.plan, 'visual_stop')
            finally:
                invocation.active = False
                self.runtime.inflight.pop(id(invocation), None)
                _CURRENT.reset(token)

    def envelope(self, invocation, session_id, command, params):
        plan = invocation.plan
        if plan is None or plan.connection_id != session_id:
            raise ToolError('connection_changed')
        kind = command.removeprefix('visual_')
        # Final PluginHub registry await has finished. Lifecycle stop may run
        # after the SDK session closes; it only carries the exact old identity.
        if kind != 'stop':
            self.bound(invocation, preparing=kind == 'prepare')
        expected = ({'ttl_seconds': invocation.arguments['ttl_seconds']} if kind == 'prepare' else
                    {'correction_reason': invocation.arguments['correction_reason']} if kind == 'capture' else
                    {'attempt_id': invocation.arguments['attempt_id']} if kind == 'collect' else {})
        if params != expected:
            raise ToolError('unexpected_arguments')
        return ROUTE, {'protocol': 1, 'kind': kind, 'project_id': self.runtime.project_id,
            'client_id': self.runtime.wire_client(invocation), 'connection_id': session_id,
            'task_id': plan.task_id, 'plan_id': plan.plan_id, 'body': params}

    async def prepare(self, task_id, ttl_seconds):
        invocation = self.runtime.current()
        client = invocation.client_id
        if client in self.preparing:
            raise ToolError('prepare_in_progress')
        self.preparing[client] = invocation
        returned = None
        try:
            previous = self.plans.pop(client, None)
            if previous is not None:
                await self.runtime.notify_stop(client, previous, 'visual_stop')
            connection = await self.runtime.connection()
            self.bound(invocation, preparing=True)
            pending = VisualPlan(exact_id(task_id), connection, time.monotonic() + ttl_seconds,
                                 approval_client=invocation.approval_client)
            invocation.plan = pending
            result = await send(connection, 'visual_prepare', {'ttl_seconds': ttl_seconds})
            if type(result) is dict and type(result.get('data')) is dict and result['data'].get('plan_id'):
                returned = VisualPlan(task_id, connection, pending.expires_at,
                    exact_id(result['data']['plan_id']), invocation.approval_client)
            checked = checked_reply('prepare', result, pending, {})
            await self.recheck(invocation, preparing=True)
            if result['success']:
                self.plans[client] = returned
                invocation.plan = returned
            return checked
        except BaseException:
            if returned is not None:
                await self.runtime.notify_stop(client, returned, 'visual_stop')
            raise
        finally:
            if self.preparing.get(client) is invocation:
                self.preparing.pop(client)

    async def dispatch(self, kind, task_id, plan_id, body):
        invocation = self.runtime.current()
        plan = self.plans.get(invocation.client_id)
        if (plan is None or plan.task_id != task_id or plan.plan_id != plan_id
                or (kind != 'stop' and time.monotonic() >= plan.expires_at)):
            raise ToolError('plan_not_current')
        invocation.plan = plan
        if kind in ('capture', 'collect') and plan.busy:
            raise ToolError('visual_operation_in_progress')
        if kind == 'capture' and not (
                (plan.attempts_used == 0 and body['correction_reason'] == '') or
                (plan.attempts_used == 1 and plan.sent and body['correction_reason'] != '')):
            raise ToolError('visual_budget_or_correction_invalid')
        if kind == 'collect' and (plan.sent or not plan.attempt_id or body['attempt_id'] != plan.attempt_id):
            raise ToolError('image_not_available')
        if kind == 'stop':
            self.plans.pop(invocation.client_id)
        exclusive = kind in ('capture', 'collect')
        if exclusive:
            plan.busy = True
        try:
            result = await send(plan.connection_id, 'visual_' + kind, body)
            checked = checked_reply(kind, result, plan, body)
        finally:
            if exclusive:
                plan.busy = False
        if result['success'] and kind == 'capture':
            plan.attempts_used = result['data']['attempts_used']
            plan.attempt_id = result['data']['attempt_id']
            plan.sent = False
        elif isinstance(checked, ToolResult):
            plan.sent = True
        return checked


def register(server, visual):
    @server.tool
    async def visual_prepare(task_id: str, ttl_seconds: float, ctx: Context) -> dict:
        """仅创建视觉pending清单；须Unity本地批准，不是图片外发批准。"""
        return await visual.prepare(task_id, ttl_seconds)

    @server.tool
    async def visual_capture(task_id: str, plan_id: str, correction_reason: str, ctx: Context) -> dict:
        """采集已有SceneView；首次空修正原因，最多一次有原因修正；仅本地预览回执。"""
        return await visual.dispatch('capture', task_id, plan_id, {'correction_reason': correction_reason})

    @server.tool
    async def visual_collect(task_id: str, plan_id: str, attempt_id: str, ctx: Context) -> ToolResult:
        """仅领取此张Unity本地确认图为MCP图像；未确认只给回执，不代表模型已识图。"""
        result = await visual.dispatch('collect', task_id, plan_id, {'attempt_id': attempt_id})
        return result if isinstance(result, ToolResult) else ToolResult(structured_content=result)

    @server.tool
    async def visual_status(task_id: str, plan_id: str, ctx: Context) -> dict:
        """仅原任务状态回执；不返回图像，不续权。"""
        return await visual.dispatch('status', task_id, plan_id, {})

    @server.tool
    async def visual_stop(task_id: str, plan_id: str, ctx: Context) -> dict:
        """停止精确视觉任务，不重试、不保存场景、不转移视觉授权。"""
        return await visual.dispatch('stop', task_id, plan_id, {})
