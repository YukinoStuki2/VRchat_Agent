"""Uninstalled host-side new-conversation scope. Import starts nothing."""
import asyncio
import secrets
import json
from contextlib import asynccontextmanager
if __package__:
    from .hermes_binding import bind, Binding
else:
    from hermes_binding import bind, Binding


@asynccontextmanager
async def conversation(peer, *, include, options):
    """Own one new agent and native peer; no live-agent replacement or model call."""
    from tools.registry import registry
    identity = 'vrc-' + secrets.token_hex(24)
    binding = await bind(peer, registry, conversation_id=identity, include=include)
    async with bound_conversation(binding, options=options) as agent:
        yield agent


@asynccontextmanager
async def bound_conversation(binding, *, options, middleware_ctx=None):
    """Construct once from a trusted receiver claim; never rebind its peer."""
    from tools.registry import registry
    from run_agent import AIAgent
    from model_tools import get_tool_definitions
    if not isinstance(binding, Binding) or getattr(binding, '_constructed', False):
        raise ValueError('candidate_construction_used')
    binding._constructed = True
    identity = binding._conversation
    agent = None
    worker = None
    middleware = None
    try:
        if type(options) is not dict or {'session_id','enabled_toolsets','disabled_toolsets','prefill_messages'} & options.keys():
            raise ValueError('candidate_construction_options')
        options = options.copy()
        names = [item['function']['name'] for item in binding.snapshot()]
        toolset = registry.get_entry(names[0]).toolset
        expected = json.loads(json.dumps(get_tool_definitions(enabled_toolsets=[toolset],quiet_mode=True)))
        def close_owned(instance):
            instance.session_id = identity
            instance.close()

        def construct():
            # Retain ownership even if native __init__ fails partway through.
            instance = AIAgent.__new__(AIAgent)
            instance.session_id = identity  # close() must never see an empty/shared ID.
            try:
                AIAgent.__init__(instance, **options,
                    session_id=identity, enabled_toolsets=[toolset])
                return instance
            except BaseException:
                try:
                    close_owned(instance)
                finally:
                    raise RuntimeError('candidate_construction_failed') from None
        worker = asyncio.create_task(asyncio.to_thread(construct))
        agent = await asyncio.shield(worker)
        if (agent.session_id != identity or agent.enabled_toolsets != [toolset]
                or agent.valid_tool_names != {t['function']['name'] for t in expected}
                or agent.tools != expected):
            raise RuntimeError('candidate_construction_mismatch')
        agent.tools = json.loads(json.dumps(agent.tools))  # Before the first turn only.
        binding.attach_main_agent(agent)
        if __package__:
            from .hermes_image_egress import ImagePeer
        else:
            from hermes_image_egress import ImagePeer
        if isinstance(binding._peer, ImagePeer):
            from hermes_cli.plugins import PluginContext
            if not isinstance(middleware_ctx, PluginContext):
                raise ValueError('candidate_main_middleware_context_required')
            peer = binding._peer
            await peer.bind_main(agent,collect_name=binding._tool_names.get('visual_collect','candidate-no-image-tool'))
            middleware = middleware_ctx.register_middleware('llm_execution',peer.execute_main)
            peer.route_guard = lambda: middleware.active and binding._image_main_current()
        yield agent
    finally:
        async def finish():
            try:
                await binding.close()
            finally:
                try:
                    if worker is not None:
                        try:
                            instance = await worker
                        except BaseException:
                            pass  # Failed constructors already closed their partial object.
                        else:
                            await asyncio.to_thread(close_owned, instance)
                finally:
                    if middleware is not None:middleware.dispose()
        cleanup = asyncio.create_task(finish())
        cancelled = None
        while not cleanup.done():
            try:
                await asyncio.shield(cleanup)
            except asyncio.CancelledError as exc:
                cancelled = exc
        cleanup.result()
        if cancelled is not None:
            raise cancelled
