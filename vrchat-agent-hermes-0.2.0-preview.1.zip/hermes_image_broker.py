"""Linux candidate image custody and fixed-main Chat egress. Import is inert.
An inherited control pipe owns one fixed-target MCP connection and one frozen
main route. Pixels never leave through IPC; custody receipts do not prove model
understanding. Activation and real endpoints remain separate approval boundaries.
"""
import asyncio
import base64
import copy
import hashlib
import json
import math
import os
import secrets
import sys
import time

LIMIT = 2 * 1024 * 1024


def unique(pairs):
    result = dict(pairs)
    if len(result) != len(pairs):
        raise ValueError('duplicate_field')
    return result


def decode(raw):
    def bad(value):raise ValueError('non_json_constant')
    return json.loads(raw, object_pairs_hook=unique, parse_constant=bad)




def checked_headers(headers, api_key):
    # This slice supports one unambiguous static Bearer identity only. Preserve
    # accepted effective headers; never reconstruct auth from a second source.
    if type(headers) is not dict or type(api_key) is not str or not api_key:
        raise ValueError('main_auth_identity_unsupported')
    normalized = {}
    for name,value in headers.items():
        if (type(name) is not str or type(value) is not str or not name
                or name.lower() in normalized or any(c in name+value for c in ('\r','\n'))):
            raise ValueError('main_auth_identity_unsupported')
        normalized[name.lower()] = value
    if normalized.get('authorization') != 'Bearer '+api_key:
        raise ValueError('main_auth_identity_unsupported')
    return dict(headers)


def contains_previous_image(value, fingerprints):
    """Exact canonical PNG encodings, not arbitrary encoding/steganography.
    Only length/SHA256 survive a plan reset, never old pixels or base64. Search
    work is bounded and excess rejects; a new connection resets this history.
    """
    offset = 0; work = 0; matches = 0
    while True:
        offset = value.find('iVBORw0KGgo',offset)
        if offset < 0:return False
        matches += 1
        if matches > 256:raise ValueError('image_echo_scan_budget')
        for size,digest in fingerprints:
            if offset+size > len(value):continue
            work += size
            if work > 8*1024*1024:raise ValueError('image_echo_scan_budget')
            candidate = value[offset:offset+size]
            if candidate.isascii() and hashlib.sha256(candidate.encode('ascii')).hexdigest()==digest:
                return True
        offset += 1


def checked_completion(raw, body, model, encodings, fingerprints=()):
    from openai._streaming import SSEDecoder
    if body.get('stream'):
        events=list(SSEDecoder().iter_bytes(iter([raw])))
        if not events or events[-1].data!='[DONE]':raise ValueError('truncated_stream')
        records=[event.json() for event in events[:-1]]
        if not records or not any(c.get('finish_reason') in ('stop','tool_calls')
            for record in records for c in record.get('choices',[])):raise ValueError('incomplete')
    else:records=[decode(raw)]
    if any(r.get('model')!=model or 'error' in r for r in records):raise ValueError('response_route')
    # SDK accumulation includes tool name/argument/refusal fragments,
    # unlike scanning only delta.content. Unknown schema fields fail closed.
    from openai.types.chat import ChatCompletion, ChatCompletionChunk
    from openai.lib.streaming.chat import ChatCompletionStreamState
    from pydantic import BaseModel
    def reject_extensions(value):
        if isinstance(value,BaseModel):
            if value.model_extra:raise ValueError('unknown_response_field')
            for name in type(value).model_fields:reject_extensions(getattr(value,name))
        elif isinstance(value,(list,tuple)):
            for child in value:reject_extensions(child)
        elif isinstance(value,dict):
            for child in value.values():reject_extensions(child)
    if body.get('stream'):
        state=ChatCompletionStreamState();finished=set()
        for event,record in zip(events[:-1],records):
            if event.event or event.id or event.retry:raise ValueError('unknown_sse_control')
            chunk=ChatCompletionChunk.model_validate(record,strict=True)
            reject_extensions(chunk)
            if chunk.object!='chat.completion.chunk':raise ValueError('response_kind')
            for choice in chunk.choices:
                if choice.index in finished:raise ValueError('after_finish')
                if choice.finish_reason is not None:finished.add(choice.index)
            state.handle_chunk(chunk)
        completion=state.get_final_completion()
        if {choice.index for choice in completion.choices}!=finished:raise ValueError('unfinished_choice')
    else:
        completion=ChatCompletion.model_validate(records[0],strict=True)
        reject_extensions(completion)
    # Function arguments are JSON embedded inside a JSON string. The SDK
    # accumulates fragments but does not parse unregistered tools' arguments.
    def strict_object(pairs):
        result={}
        for key,value in pairs:
            if key in result:raise ValueError('duplicate_argument_key')
            result[key]=value
        return result
    def invalid_constant(value):raise ValueError('non_json_constant')
    for choice in completion.choices:
        message=choice.message
        functions=[call.function for call in message.tool_calls or []]
        if message.function_call is not None:functions.append(message.function_call)
        for function in functions:
            args=function.arguments
            if len(args.encode('utf-8'))>1048576:raise ValueError('argument_budget')
            value=json.loads(args,object_pairs_hook=strict_object,parse_constant=invalid_constant)
            if not isinstance(value,dict):raise ValueError('argument_object_required')
            # The host's tool_call bridge normally parses string arguments again.
            # Admit only the documented object form, not that compatibility path.
            if function.name=='tool_call' and not isinstance(value.get('arguments'),dict):
                raise ValueError('bridge_object_arguments_required')
            pending=[(value,0)]
            while pending:
                value,depth=pending.pop()
                if depth>16:raise ValueError('argument_depth')
                if isinstance(value,dict):
                    pending.extend((child,depth+1) for pair in value.items() for child in pair)
                elif isinstance(value,list):pending.extend((child,depth+1) for child in value)
                elif isinstance(value,str) and (any(encoded in value for encoded in encodings) or 'data:image' in value or contains_previous_image(value,fingerprints)):
                    raise ValueError('image_echo')
    # Check decoded/assembled known channels and original event metadata.
    # Not a defense against arbitrary re-encoding or covert channels.
    projected=json.dumps(completion.model_dump(mode='json'),ensure_ascii=False)
    decoded=json.dumps(records,ensure_ascii=False)
    if any(any(encoded in value for encoded in encodings) or 'data:image' in value or contains_previous_image(value,fingerprints)
           for value in (raw.decode('utf-8'),decoded,projected)) or any(base64.b64decode(encoded) in raw for encoded in encodings):
        raise ValueError('image_echo')
    return completion.model_dump(mode='json')


class Custody:
    def __init__(self, peer, expires_at):
        self.peer = peer
        self.session = peer.session
        self.expires = time.monotonic() + max(0, expires_at-time.time())
        self.wall_expires = expires_at
        self.plan = None
        self.images = {}
        self.stopped = False
        self.changed = asyncio.Event()
        self.route = None
        self.generation = secrets.token_hex(24)
        self.executions = {}
        self.fingerprints = set()
        self.retired = {}  # Bounded receipt hashes only; no old pixels or grant.

    def revoke(self):
        self.stopped = True
        self.plan = None
        self.route = None
        self.executions.clear()
        self.fingerprints.clear()
        self.retired.clear()
        self.images.clear()  # Releasing references is not secure RAM erasure.
        self.changed.set()

    def current(self):
        if (self.stopped or self.peer.session is not self.session
                or time.monotonic() >= self.expires or time.time() >= self.wall_expires):
            self.revoke()
            raise ValueError('custody_unavailable')

    def plain(self, response):
        if any(part.type != 'text' for part in response.content):
            raise ValueError('unexpected_media')
        body = response.model_dump(mode='json', by_alias=True)
        raw = json.dumps(body, ensure_ascii=False, allow_nan=False)
        if (len(raw.encode()) > LIMIT or 'data:image' in raw or contains_previous_image(raw,self.fingerprints)
                or any(entry['encoded'] in raw for entry in self.images.values())):
            raise ValueError('unexpected_image_echo')
        return body

    @staticmethod
    def receipt_digest(arguments, content):
        return hashlib.sha256(json.dumps([arguments,content],sort_keys=True,
            separators=(',',':'),allow_nan=False).encode()).hexdigest()

    def retire_images(self):
        if len(self.retired)+len(self.images)>128:
            raise ValueError('retired_receipt_capacity')
        for ref,entry in self.images.items():
            self.retired[ref] = self.receipt_digest(entry['args'],{'mcp':entry['projected']})
        self.images.clear()

    def bind_main(self, route):
        import httpx
        self.current()
        fields = {'provider','requested_provider','model','api_mode','base_url','session_id',
                  'api_key','headers','collect_name'}
        if self.route is not None or type(route) is not dict or set(route) != fields:
            raise ValueError('main_binding_invalid')
        if (any(type(route[k]) is not str or not route[k] for k in fields-{'headers'})
                or route['api_mode'] != 'chat_completions' or type(route['headers']) is not dict):
            raise ValueError('main_route_unsupported')
        url = httpx.URL(route['base_url'])
        if (url.scheme != 'https' or not url.host or url.username or url.password or url.query or url.fragment
                or '%' in route['base_url'] or len(route['api_key'])>8192):
            raise ValueError('main_route_unsupported')
        route = copy.deepcopy(route)
        route['endpoint'] = str(url).rstrip('/')+'/chat/completions'
        route['headers'] = checked_headers(route['headers'],route['api_key'])
        self.route = route
        return {'main_bound':True,'generation':self.generation}

    async def execute_main(self, context, body):
        import httpx
        self.current()
        route = self.route
        if route is None or type(context) is not dict or type(body) is not dict:
            raise ValueError('main_unbound')
        wanted = {k:route[k] for k in ('session_id','provider','requested_provider','model','api_mode','base_url')}
        wanted['generation'] = self.generation
        if (set(context) != set(wanted)|{'turn_id','api_request_id'}
                or any(context.get(k)!=v for k,v in wanted.items())
                or any(type(context.get(k)) is not str or not 0<len(context[k])<=512 for k in ('turn_id','api_request_id'))
                or body.get('model') != route['model']
                or set(body)-{'model','messages','tools','tool_choice','max_completion_tokens','temperature','stream','stream_options'}
                or body.get('stream') is not True or body.get('stream_options') != {'include_usage':True}):
            raise ValueError('main_contract_invalid')
        canonical = json.dumps(body,sort_keys=True,separators=(',',':'),allow_nan=False)
        if len(canonical.encode())>1024*1024:raise ValueError('main_request_budget')
        key = (context['turn_id'],context['api_request_id'])
        digest = hashlib.sha256(canonical.encode()).hexdigest()
        previous = self.executions.get(key)
        if previous is None:
            if len(self.executions)>=32:raise ValueError('main_execution_capacity')
            previous = self.executions[key] = [digest,0]
        if previous[0]!=digest or previous[1]>=3:raise ValueError('main_replay_limit')
        previous[1]+=1  # bounded same-request physical repeats; no autonomous retry
        outgoing = copy.deepcopy(body)
        messages = outgoing.get('messages')
        if type(messages) is not list:raise ValueError('main_messages_invalid')
        calls = {};used=set();residual_messages=copy.deepcopy(messages)
        for index,message in enumerate(messages):
            if type(message) is not dict:raise ValueError('main_message_invalid')
            if message.get('role')=='assistant':
                for call in message.get('tool_calls') or []:
                    ident=call['id'];function=call['function']
                    if ident in calls:raise ValueError('duplicate_tool_id')
                    name=function['name'];arguments=decode(function['arguments'])
                    if name=='tool_call':name,arguments=arguments['name'],arguments['arguments']
                    calls[ident]=(name,arguments)
            if message.get('role')!='tool' or type(message.get('content')) is not str:continue
            content=message['content']
            matching=[ref for ref in (*self.images,*self.retired) if ref in content]
            if not matching:continue
            if len(matching)!=1:raise ValueError('image_receipt_ambiguous')
            ref=matching[0]
            if ref in self.retired:
                call=calls.get(message.get('tool_call_id'))
                if (ref in used or call is None or call[0]!=route['collect_name']
                        or self.receipt_digest(call[1],decode(content))!=self.retired[ref]):
                    raise ValueError('retired_receipt_invalid')
                used.add(ref)
                message['content']=json.dumps({'candidate_image_retired':True,'pixels_sent':False})
                residual_messages[index]['content']=''
                continue
            entry=self.images[ref]
            if (ref in used or time.monotonic()>=entry['deadline']
                    or calls.get(message.get('tool_call_id'))!=(route['collect_name'],entry['args'])
                    or decode(content)!={'mcp':entry['projected']}):
                raise ValueError('image_receipt_invalid')
            used.add(ref)
            residual_messages[index]['content']=''
            message['content']=[{'type':'text','text':content},
                {'type':'image_url','image_url':{'url':'data:image/png;base64,'+entry['encoded']}}]
        # Receipts elsewhere are not pixel authority. Unknown/pruned references
        # cannot resurrect images; there is no download or raw-image IPC method.
        residual = json.dumps({**body,'messages':residual_messages},sort_keys=True,separators=(',',':'),allow_nan=False)
        if 'vrc-image-ref:' in residual:raise ValueError('image_receipt_unmatched')
        if 'data:image' in canonical:raise ValueError('host_image_forbidden')
        encodings=[entry['encoded'] for entry in self.images.values()]
        if any(encoded in canonical for encoded in encodings) or contains_previous_image(canonical,self.fingerprints):raise ValueError('host_image_forbidden')
        headers=checked_headers(route['headers'],route['api_key'])
        async with httpx.AsyncClient(trust_env=False,follow_redirects=False,timeout=20) as client:
            async with client.stream('POST',route['endpoint'],json=outgoing,headers=headers) as response:
                if response.status_code != 200:raise ValueError('main_service_error')
                raw=bytearray()
                async for part in response.aiter_bytes():
                    raw.extend(part)
                    if len(raw)>1024*1024:raise ValueError('main_response_budget')
        self.current()
        if self.route is not route:raise ValueError('main_route_revoked')
        return checked_completion(bytes(raw),body,route['model'],encodings,self.fingerprints)

    async def call(self, name, args):
        self.current()
        started = time.monotonic()
        if name == 'visual_prepare':
            self.plan = None
            self.retire_images()
            ttl = args.get('ttl_seconds')
            if (type(ttl) not in (int,float) or not math.isfinite(ttl) or not 0 < ttl <= 900
                    or type(args.get('task_id')) is not str or not args['task_id']):
                raise ValueError('visual_prepare_invalid')
        elif name.startswith('visual_'):
            plan = self.plan
            if (plan is None or any(args.get(k) != plan[k] for k in ('task_id','plan_id'))
                    or started >= plan['deadline']):
                raise ValueError('visual_plan_unavailable')
            if name == 'visual_stop':
                self.plan = None
                self.retire_images()
        response = await self.session.call_tool(name, args)
        self.current()
        if name == 'visual_collect' and any(p.type != 'text' for p in response.content):
            if __package__:
                from .hermes_visual import validate_image
            else:
                from hermes_visual import validate_image
            receipt, encoded, size = validate_image(response, args)
            plan = self.plan
            if (plan is None or time.monotonic() >= plan['deadline'] or len(self.images) >= 2
                    or len(self.retired)+len(self.images)>=128):
                raise ValueError('visual_capacity_or_expiry')
            data = receipt['data']
            if data['attempts_used'] != len(self.images)+1:
                raise ValueError('visual_attempt_sequence')
            fingerprint = (len(encoded),hashlib.sha256(encoded.encode('ascii')).hexdigest())
            if fingerprint not in self.fingerprints and len(self.fingerprints)>=128:
                raise ValueError('image_fingerprint_capacity')
            self.fingerprints.add(fingerprint)
            ref = 'vrc-image-ref:' + secrets.token_hex(24)
            self.images[ref] = {'encoded':encoded, 'receipt':receipt, 'bytes':size,
                                'deadline':plan['deadline'], 'task_id':plan['task_id']}
            projected = {'success':True, 'data':{**data, 'status':'image_held',
                'candidate_image_receipt':ref, 'model_delivery_confirmed':False}}
            result = {'content':[{'type':'text', 'text':json.dumps(projected)}],
                      'structuredContent':projected, 'isError':False}
            # Normalize once through the same SDK model the parent consumes.
            from mcp.types import CallToolResult
            self.images[ref]['projected'] = CallToolResult.model_validate(result).model_dump(mode='json',by_alias=True)
            self.images[ref]['args'] = copy.deepcopy(args)
            return result
        body = self.plain(response)
        data = response.structured_content
        if name == 'visual_prepare' and not response.is_error:
            if (type(data) is not dict or data.get('success') is not True
                    or type(data.get('data')) is not dict or data['data'].get('status') != 'pending'
                    or type(data['data'].get('plan_id')) is not str or not data['data']['plan_id']):
                raise ValueError('visual_prepare_receipt')
            self.plan = {'task_id':args['task_id'], 'plan_id':data['data']['plan_id'],
                         'deadline':min(self.expires, started+args['ttl_seconds'])}
            self.changed.set()
        if name == 'visual_collect':
            receipts = [data] + [decode(p.text) for p in response.content]
            if any(type(r) is dict and type(r.get('data')) is dict
                   and r['data'].get('status') == 'image_confirmed' for r in receipts):
                raise ValueError('image_missing')
        if name.startswith('visual_') and response.is_error:
            self.plan = None
            self.retire_images()
        return body


async def serve():
    if sys.platform != 'linux' or not hasattr(os,'pidfd_open'):
        return 1
    loop = asyncio.get_running_loop()
    reader = asyncio.StreamReader(limit=LIMIT)
    protocol = asyncio.StreamReaderProtocol(reader)
    transport, _ = await loop.connect_read_pipe(lambda:protocol, sys.stdin.buffer)
    parent = os.pidfd_open(os.getppid())
    parent_lost = asyncio.Event()
    loop.add_reader(parent, parent_lost.set)
    peer = None
    vault = None
    lifetime = None
    clean = False
    def emit(value):
        wire = json.dumps(value,allow_nan=False).encode()+b'\n'
        if len(wire)>LIMIT:raise ValueError('control_output_budget')
        sys.stdout.buffer.write(wire);sys.stdout.buffer.flush()
    async def line():
        incoming = asyncio.create_task(reader.readline())
        orphan = asyncio.create_task(parent_lost.wait())
        try:
            watches = [incoming,orphan] + ([lifetime] if lifetime is not None else [])
            done, _ = await asyncio.wait(watches,timeout=3600,return_when=asyncio.FIRST_COMPLETED)
            if lifetime is not None and lifetime in done:
                vault.revoke()
                return None
            if incoming not in done or orphan in done:raise ValueError('parent_unavailable')
            raw = incoming.result()
            if not raw:return None  # inherited pipe EOF is revocation, not a new grant
            if len(raw)>LIMIT:raise ValueError('control_budget')
            return decode(raw)
        finally:
            for task in (incoming,orphan):
                if not task.done():task.cancel()
            await asyncio.gather(incoming,orphan,return_exceptions=True)
    try:
        bootstrap = await line()
        if type(bootstrap) is not dict or set(bootstrap) != {'handoff','parent_pid'} or bootstrap['parent_pid'] != os.getppid():
            raise ValueError('bootstrap_invalid')
        if __package__:
            from .hermes_connection import connect
        else:
            from hermes_connection import connect
        peer = await connect(**bootstrap['handoff'])
        vault = Custody(peer,bootstrap['handoff']['expires_at'])
        bootstrap.clear()
        async def watch_lifetime():
            while not vault.stopped:
                deadline = min(vault.expires, vault.plan['deadline'] if vault.plan else vault.expires)
                delay = min(deadline-time.monotonic(),vault.wall_expires-time.time())
                if delay <= 0 or peer.session is not vault.session:return
                vault.changed.clear()
                changed = asyncio.create_task(vault.changed.wait())
                try:
                    done, _ = await asyncio.wait((changed,peer._task),timeout=delay,
                                                 return_when=asyncio.FIRST_COMPLETED)
                    if changed not in done or peer._task in done:return
                finally:
                    if not changed.done():changed.cancel()
                    await asyncio.gather(changed,return_exceptions=True)
        lifetime = asyncio.create_task(watch_lifetime())
        emit({'ready':True})
        async def execute(message):
            if type(message) is not dict or set(message) != {'op','args'}:
                raise ValueError('control_invalid')
            op, args = message['op'], message['args']
            vault.current()
            if op == 'bind_main':return vault.bind_main(args)
            if op == 'execute_main':
                if type(args) is not dict or set(args)!={'context','body'}:raise ValueError('main_request_invalid')
                return await vault.execute_main(args['context'],args['body'])
            if op == 'list':
                result = await vault.session.list_tools()
                vault.current()
                return result.model_dump(mode='json',by_alias=True)
            if op == 'call':
                if (type(args) is not dict or set(args) != {'name','arguments'}
                        or type(args['name']) is not str or type(args['arguments']) is not dict):
                    raise ValueError('call_invalid')
                return await vault.call(args['name'],args['arguments'])
            raise ValueError('unsupported_control')

        message = await line()
        while message is not None and message != {'op':'stop','args':{}}:
            operation = asyncio.create_task(execute(message))
            incoming = asyncio.create_task(line())
            try:
                done, _ = await asyncio.wait((operation,incoming),return_when=asyncio.FIRST_COMPLETED)
                # EOF/stop wins a tie with a completed image. No further operation
                # is allowed until the previous result was consumed by the owner.
                if incoming in done:
                    vault.revoke()
                    message = incoming.result()
                    if message not in (None, {'op':'stop','args':{}}):
                        raise ValueError('concurrent_control')
                    break
                emit(operation.result())
                message = await incoming
            finally:
                if not operation.done():
                    vault.revoke()
                    operation.cancel()
                if not incoming.done():incoming.cancel()
                await asyncio.gather(operation,incoming,return_exceptions=True)
        vault.revoke()
        await peer.shutdown()
        clean = True
    except (Exception, asyncio.CancelledError):
        try:emit({'error':'candidate_custody_stopped'})
        except Exception:pass
    finally:
        if vault is not None:vault.revoke()
        if lifetime is not None:
            lifetime.cancel()
            await asyncio.gather(lifetime,return_exceptions=True)
        if peer is not None and not clean:
            try:
                await peer.shutdown()
                clean = True
            except Exception:pass
        if peer is not None:
            try:emit({'stopped':True,'session_cleanup_confirmed':bool(clean and peer.session_cleanup_confirmed)})
            except Exception:pass
        loop.remove_reader(parent);os.close(parent);transport.close()
    return 0 if clean else 1


def main():
    raise SystemExit(asyncio.run(serve()))
