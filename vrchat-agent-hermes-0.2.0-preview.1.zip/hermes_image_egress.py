"""Candidate-only inherited IPC peer. Import is inert; no raw media API.
An explicitly enabled candidate may bind one new native agent via llm_execution.
One peer/SDK session serves every tool; only the child sends image-bearing requests.
No real route/profile is configured here. Import starts nothing.
"""
import asyncio
import copy
import json
import os
from pathlib import Path
import sys

LIMIT = 2 * 1024 * 1024


class ImagePeer:
    def __init__(self, proc):
        self.proc = proc
        self.loop = asyncio.get_running_loop()
        self.agent = None
        self.main_route = None
        self.generation = None
        self.route_guard = None
        self.session = self
        self.session_cleanup_confirmed = False
        self.lock = asyncio.Lock()
        self._shutdown = None
        self._failed = False
        self._stop_received = False

    async def _read(self):
        raw = await asyncio.wait_for(self.proc.stdout.readline(), 35)
        if not raw or len(raw)>LIMIT:
            raise ValueError('candidate_image_control_unavailable')
        value = json.loads(raw)
        if value == {'error':'candidate_custody_stopped'}:
            self._failed = True
            self.session = None
        if type(value) is not dict or 'error' in value:
            raise ValueError('candidate_image_control_denied')
        if value == {'stopped':True,'session_cleanup_confirmed':True}:
            self._stop_received = True
            self.session_cleanup_confirmed = True
            self.session = None
        return value

    async def _exchange(self, op, args):
        wire = json.dumps({'op':op,'args':args},allow_nan=False).encode()+b'\n'
        if len(wire)>LIMIT:raise ValueError('candidate_image_control_budget')
        self.proc.stdin.write(wire)
        await self.proc.stdin.drain()
        return await self._read()

    async def _request(self, op, args):
        async with self.lock:
            if self.session is not self:
                raise ValueError('candidate_image_peer_closed')
            try:
                result = await self._exchange(op,args)
                if self.session is not self:
                    raise ValueError('candidate_image_peer_closed')
                return result
            except BaseException:
                self.session = None
                self._failed = True
                self.proc.stdin.close()
                raise

    @staticmethod
    def _transport_snapshot(agent):
        # Inspect the transport selected for the actual endpoint, not the
        # constructor kwargs: the native factory injects HTTP clients in a copy.
        import httpx, httpcore, ssl
        from httpcore._backends.sync import SyncBackend
        from agent.process_bootstrap import _get_proxy_for_base_url
        http = agent.client._client
        endpoint = httpx.URL(str(agent.client.base_url).rstrip('/')+'/chat/completions')
        if type(http) is not httpx.Client or http.is_closed or _get_proxy_for_base_url(str(endpoint)) is not None:
            raise ValueError('candidate_main_transport_unsupported')
        transport = http._transport_for_url(endpoint)
        pool = getattr(transport,'_pool',None)
        if (type(transport) is not httpx.HTTPTransport or type(pool) is not httpcore.ConnectionPool
                or pool._proxy is not None or type(pool._network_backend) is not SyncBackend
                or pool._uds is not None or pool._local_address is not None
                or pool._socket_options is not None or not pool._http1 or pool._http2
                or pool._retries != 0):
            raise ValueError('candidate_main_transport_unsupported')
        tls = pool._ssl_context
        if type(tls) is not ssl.SSLContext or tls.verify_mode != ssl.CERT_REQUIRED or not tls.check_hostname:
            raise ValueError('candidate_main_transport_unsupported')
        # Current transport identity/configuration are rechecked before dispatch
        # and after its response; no proxy env or host client is changed here.
        return (id(http),id(transport),id(pool),id(pool._network_backend),id(tls),
                tls.verify_mode,tls.check_hostname,tls.minimum_version,tls.maximum_version,
                tls.options,tls.verify_flags,tuple(sorted(tls.get_ca_certs(binary_form=True))))

    @staticmethod
    def _snapshot(agent):
        # Values stay in memory; equality detects key/header/client/route drift.
        client = agent.client
        from openai._types import Omit
        headers = {k:v for k,v in client.default_headers.items() if not isinstance(v,Omit)}
        if __package__:
            from .hermes_image_broker import checked_headers
        else:
            from hermes_image_broker import checked_headers
        headers = checked_headers(headers,agent.api_key)
        return ({k:getattr(agent,k,None) for k in
                 ('session_id','provider','requested_provider','model','api_mode','base_url','api_key')},
                id(client), str(client.base_url), headers,
                copy.deepcopy(getattr(agent,'_client_kwargs',{})),
                id(getattr(agent,'_credential_pool',None)),ImagePeer._transport_snapshot(agent))

    async def bind_main(self, agent, *, collect_name):
        if self.agent is not None:raise ValueError('candidate_main_already_bound')
        if (agent.api_mode!='chat_completions' or getattr(agent,'_credential_pool',None) is not None
                or type(collect_name) is not str or not collect_name):
            raise ValueError('candidate_main_route_unsupported')
        snapshot = self._snapshot(agent)
        route = dict(snapshot[0])
        if str(agent.client.base_url).rstrip('/') != route['base_url'].rstrip('/'):
            raise ValueError('candidate_client_route_mismatch')
        options = getattr(agent,'_client_kwargs',{})
        if set(options)-{'api_key','base_url','timeout','default_headers','max_retries'}:
            raise ValueError('candidate_client_options_unsupported')
        route.update(headers=dict(snapshot[3]),collect_name=collect_name)
        reply = await self._request('bind_main',route)
        if set(reply)!={'main_bound','generation'} or reply['main_bound'] is not True:
            raise ValueError('candidate_main_bind_failed')
        self.agent = agent
        self.main_route = snapshot
        self.generation = reply['generation']

    def execute_main(self, request, next_call, **context):
        # Registered only by the trusted candidate constructor; not a model tool.
        agent = self.agent
        if agent is not None and context.get('session_id') not in (None, self.main_route[0]['session_id'],getattr(agent,'session_id',None)):
            return next_call(request)
        try:
            wanted = {k:self.main_route[0][k] for k in ('session_id','provider','model','api_mode','base_url')}
            if (agent is None or self.session is not self or self._snapshot(agent)!=self.main_route
                    or (self.route_guard is not None and not self.route_guard())
                    or any(context.get(k)!=v for k,v in wanted.items())
                    or not context.get('turn_id') or not context.get('api_request_id')
                    or set(request)-{'model','messages','tools','tool_choice','max_completion_tokens','timeout','temperature'}):
                raise ValueError('candidate_main_context_invalid')
            try:current=asyncio.get_running_loop()
            except RuntimeError:current=None
            if current is self.loop:raise ValueError('candidate_main_wrong_thread')
            wire = copy.deepcopy(request)
            wire.pop('timeout',None)
            wire.update(stream=True,stream_options={'include_usage':True})
            correlated = {**wanted,'requested_provider':self.main_route[0]['requested_provider'],
                          'generation':self.generation,'turn_id':context['turn_id'],'api_request_id':context['api_request_id']}
            future = asyncio.run_coroutine_threadsafe(self._request('execute_main',{'context':correlated,'body':wire}),self.loop)
            response = future.result(timeout=30)
            if (self.session is not self or self._snapshot(agent)!=self.main_route
                    or (self.route_guard is not None and not self.route_guard())):
                raise ValueError('candidate_main_route_changed')
            from openai.types.chat import ChatCompletion
            return ChatCompletion.model_validate(response,strict=True)
        except Exception:
            # Hermes middleware exceptions are fail-open: return an explicit
            # terminal rejection, while EOF revokes the actual image authority.
            self.session = None
            self.loop.call_soon_threadsafe(self.proc.stdin.close)
            from openai.types.chat import ChatCompletion
            return ChatCompletion(id='candidate-local-rejection',object='chat.completion',created=0,
                model=self.main_route[0]['model'] if self.main_route else 'candidate-unbound',
                choices=[{'index':0,'finish_reason':'stop','message':{'role':'assistant',
                'content':'[candidate:visual_branch_stopped] 视觉分支已终止：绑定、授权或响应校验失败；未切换模型或辅助识图。'}}])

    async def list_tools(self):
        from mcp.types import ListToolsResult
        return ListToolsResult.model_validate(await self._request('list',{}))

    async def call_tool(self, name, arguments):
        from mcp.types import CallToolResult
        return CallToolResult.model_validate(await self._request('call',{'name':name,'arguments':arguments}))

    async def _finish(self):
        natural = True
        try:
            async with self.lock:
                # A cancelled waiter may leave one projected result ahead of
                # the cleanup receipt. Discard it; never deliver after revoke.
                for _ in range(2):
                    if self._stop_received:break
                    try:await self._read()
                    except ValueError:
                        if not self._failed:raise
        finally:
            self.proc.stdin.close()
            try:
                await self.proc.stdin.wait_closed()
            except (BrokenPipeError,ConnectionResetError):pass
            try:
                await asyncio.wait_for(self.proc.wait(),8)
            except asyncio.TimeoutError:
                natural = False
                self.proc.kill()
                await self.proc.wait()
        if not natural or self.proc.returncode != 0 or not self.session_cleanup_confirmed:
            raise RuntimeError('candidate_image_cleanup_unconfirmed')

    async def shutdown(self):
        self.session = None
        # Revocation cannot queue behind an in-flight result on the IPC lock.
        # EOF wakes the child's concurrent control reader before cancellation.
        self.proc.stdin.close()
        if self._shutdown is None:self._shutdown = asyncio.create_task(self._finish())
        cancelled = None
        while not self._shutdown.done():
            try:await asyncio.shield(self._shutdown)
            except asyncio.CancelledError as exc:cancelled = exc
        self._shutdown.result()
        if cancelled is not None:raise cancelled


async def connect(**handoff):
    if sys.platform != 'linux' or not hasattr(os,'pidfd_open'):
        raise ValueError('candidate_image_platform_unsupported')
    if __package__:
        from .hermes_connection import validate_handoff
    else:
        from hermes_connection import validate_handoff
    validate_handoff(**handoff)
    import tools.mcp_tool
    host = Path(tools.mcp_tool.__file__).resolve().parents[1]
    clients = Path(__file__).resolve().parent
    # Paths are code/dependency locations only. Credentials are written once to
    # the inherited pipe, never argv/env. No user-config provider resolution.
    code = ('import sys;sys.path[:0]='+repr([str(host),str(clients)])+
            ';from hermes_image_broker import main;main()')
    env = {k:os.environ[k] for k in ('PATH','HOME','HERMES_HOME','LANG','TMPDIR') if k in os.environ}
    env['PYTHONDONTWRITEBYTECODE']='1'
    proc = await asyncio.create_subprocess_exec(sys.executable,'-I','-B','-c',code,
        stdin=asyncio.subprocess.PIPE,stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,env=env,limit=LIMIT)
    peer = ImagePeer(proc)
    try:
        proc.stdin.write(json.dumps({'handoff':handoff,'parent_pid':os.getpid()},allow_nan=False).encode()+b'\n')
        await proc.stdin.drain()
        if await peer._read() != {'ready':True}:
            raise ValueError('candidate_image_peer_not_ready')
        return peer
    except BaseException:
        peer._failed = True
        try:await peer.shutdown()
        finally:raise RuntimeError('candidate_image_connect_failed') from None
