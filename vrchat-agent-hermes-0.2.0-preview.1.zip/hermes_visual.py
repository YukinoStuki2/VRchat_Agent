"""Product-only MCP image adaptation; no captures, model calls or image cache.
Native host helpers are optional/versioned dependencies, never copied or patched.
An envelope handed to Hermes can enter its ordinary history/hooks; closing this
adapter cannot retract already-consumed images or previously sent model requests.
"""
import base64
import hashlib
import json
import struct


def validate_image(response, args):
    """Shared strict decoder; callers must own the image custody boundary."""
    from tools.computer_use.cua_backend import _extract_tool_result
    if response.is_error or [part.type for part in response.content] != ['text', 'image']:
        raise ValueError('candidate_visual_reply_invalid')
    result = _extract_tool_result(response)
    receipt = result['structuredContent']
    if (type(receipt) is not dict or set(receipt) != {'success','data'}
            or receipt['success'] is not True or result['data'] != receipt
            or result['image_mime_types'] != ['image/png'] or len(result['images']) != 1):
        raise ValueError('candidate_visual_reply_invalid')
    data = receipt['data']
    if (type(data) is not dict or set(data) != {'status','plan_id','attempt_id','attempts_used','read_only','sha256','imageWidth','imageHeight'}
            or data['status'] != 'image_confirmed' or data['read_only'] is not False
            or type(data['attempts_used']) is not int or data['attempts_used'] not in (1,2)
            or any(type(data[key]) is not str or not data[key] or data[key] != args.get(key) for key in ('plan_id','attempt_id'))):
        raise ValueError('candidate_visual_reply_invalid')
    encoded = result['images'][0]
    if type(encoded) is not str or len(encoded) > 700000:
        raise ValueError('candidate_visual_reply_invalid')
    raw = base64.b64decode(encoded, validate=True)
    if (not 45 <= len(raw) <= 512*1024 or raw[:16] != b'\x89PNG\r\n\x1a\n\0\0\0\rIHDR'
            or base64.b64encode(raw).decode('ascii') != encoded):
        raise ValueError('candidate_visual_reply_invalid')
    size = struct.unpack('>II', raw[16:24])
    if (any(type(data[key]) is not int for key in ('imageWidth','imageHeight'))
            or any(not 0 < dimension <= 640 for dimension in size)
            or size != (data['imageWidth'],data['imageHeight'])
            or hashlib.sha256(raw).hexdigest() != data['sha256']):
        raise ValueError('candidate_visual_reply_invalid')
    # Optional installed-host dependency: absence or permissive decoding fails closed.
    # Byte/dimension/hash checks above precede any image decoder work.
    from io import BytesIO
    from PIL import Image, ImageFile
    # Pillow.verify stops at the first IEND, before its CRC. A suffix check
    # alone would accept a corrupt IEND followed by a second valid trailer.
    if ImageFile.LOAD_TRUNCATED_IMAGES:
        raise ValueError('candidate_visual_reply_invalid')
    with BytesIO(raw) as stream, Image.open(stream, formats=['PNG']) as image:
        if (image.size != size or (image.mode == 'P'
                and (image.palette is None or not image.palette.palette))):
            raise ValueError('candidate_visual_reply_invalid')
        image.verify()  # Required chunks and CRCs; not just a matching receipt hash.
        end = stream.tell()
        if end != len(raw)-4 or raw[end-8:] != b'\0\0\0\0IEND\xaeB`\x82':
            raise ValueError('candidate_visual_reply_invalid')
    with BytesIO(raw) as stream, Image.open(stream, formats=['PNG']) as image:
        image.load()  # Verify actual compressed pixel data as well as container structure.
    return receipt, encoded, len(raw)


def convert(response, args):
    """Legacy adapter; not for the process-owned visual path."""
    from tools.vision_tools import _build_native_vision_tool_result
    receipt, encoded, byte_count = validate_image(response, args)
    text = json.dumps(receipt)
    envelope = _build_native_vision_tool_result('candidate-confirmed-image','',
        'data:image/png;base64,'+encoded,byte_count)
    envelope['content'][0] = {'type':'text','text':text}
    # The host may decline tool images. A summary must not claim pixels arrived.
    envelope['text_summary'] = json.dumps({'error':'candidate_main_image_not_delivered','receipt':receipt})
    return envelope
